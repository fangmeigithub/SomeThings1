//
//  AboutViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/26.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "AboutViewController.h"

@interface AboutViewController ()

@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =  RGB(247, 247, 247, 1);
    [self creatNavView:@"关于我们" :NO];
    [self initSub];
}

- (void)initSub
{
    UIView *headGrayV=[[UIView alloc]init];
    headGrayV.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:headGrayV];
    headGrayV.sd_layout.leftSpaceToView(self.sc,10).topSpaceToView(self.sc,74).rightSpaceToView(self.sc,10).bottomSpaceToView(self.sc,10);
    
    
    UILabel *Label = [MethodTool creatLabelWithAttribute:@"" :13 :1 :NEWSTITLECOLOR];
    Label.text = @"       格讯软件有限公司是一家专注于从事软件开发、电子商务及自动化嵌入式系统高度集成的开发商和IT服务运营商。服务涵盖服装、鞋业、饰品、线带、拉链、肉类、机械、印染、保险、金融等多个行业；公司视人才为企业最大的财富，聚集行业的专家，以创新驱动为核心，倾力打造智能自动化信息管理模式，截止2013年10月，格讯员工总数已超160人，其中本科、硕士研发人员占60%以上；自主研发了基于物联网的销售、生产、物流、财务、电商、OA办公为一体的高度集成管理平台，并获得多项独立知识产权；公司先后获得国家级高新技术企业认定、国家级双软企业认定等多项荣誉。";
    [headGrayV addSubview:Label];
    Label.sd_layout
    .leftSpaceToView(headGrayV,20)
    .topSpaceToView(headGrayV,30)
    .rightSpaceToView(headGrayV,20)
   .autoHeightRatio(0);
    
    
    UILabel *Label1 = [MethodTool creatLabelWithAttribute:@"" :13 :1 :NEWSTITLECOLOR];
    Label1.text = @"       格讯公司经十多年的技术积累及发展，已累计超过三万多家成功企业实施经验，特别是在袜业、内衣、肉类、饰品引领行业发展方向。通过软件与自动化、智能化联动，让用户真正体验新一代技术给工作、生产、管理、生活带来的快乐。公司坚持“诚信为本、客户至上，共赢共享”的经营理念，为广大企业提供真诚服务与产品。";
    [headGrayV addSubview:Label1];
    Label1.sd_layout
    .leftSpaceToView(headGrayV,20)
    .topSpaceToView(Label,4)
    .rightSpaceToView(headGrayV,20)
    .autoHeightRatio(0);
    
    
    
}

@end
