 //
//  PersonTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/26.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonTableViewCell.h"

@implementation PersonTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(247, 247, 247, 1);
        [self  addSubview:bgView];
        
        bgView.sd_layout
        .leftSpaceToView(self,0)
        .topSpaceToView(self,6)
        .rightSpaceToView(self,0)
        .bottomSpaceToView(self,0);
        
        self.leftTextLabel = [MethodTool creatLabelWithAttribute:@"" :14 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.leftTextLabel];
        self.leftTextLabel.sd_layout
        .leftSpaceToView(bgView,20)
        .centerYEqualToView(bgView)
        .widthIs(100)
        .heightIs(20);
        
        
        //别针图片
        UIImageView *imageV = [MethodTool creatImageWithAttribute:@"grayjiantou.png"];
        [bgView addSubview:imageV];
        imageV.sd_layout.rightSpaceToView(bgView,15).centerYEqualToView(bgView).widthIs(12).heightIs(12);
    
        
    }
    return self;
}


@end
