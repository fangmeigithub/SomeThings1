//
//  PersonTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/26.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonTableViewCell : UITableViewCell

@property(strong,nonatomic)UILabel *leftTextLabel;
@end
