//
//  NSString+CodeAndClean.m
//  Mall
//
//  Created by liubaojian on 15/11/4.
//  Copyright © 2015年 liubaojian. All rights reserved.
//

#import "NSString+CodeAndClean.h"

@implementation NSString (CodeAndClean)

/**
 *  汉字编码
 */
-(NSString *)encodeChinese ;
{
    return [self stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}
/**
 *  汉字解码
 */
-(NSString *)decodeChinese;
{
    return  [self stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

/**
 *  拼接字符串
 *
 *  @return 字符
 */
- (NSString *)stringWithFormMat :(NSString *)forStr;
{
    return [NSString stringWithFormat:forStr,self];
}


@end
