//
//  NSString+CodeAndClean.h
//  Mall
//
//  Created by liubaojian on 15/11/4.
//  Copyright © 2015年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CodeAndClean)

/**
 *  汉字编码
 */
-(NSString *)encodeChinese ;
/**
 *  汉字解码
 */
-(NSString *)decodeChinese;

/**
 *  拼接字符串
 *
 *  @return 字符
 */
- (NSString *)stringWithFormMat :(NSString *)forStr;



@end
