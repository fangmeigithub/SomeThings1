//
//  RootTabBarController.m
//  Hubanghu
//
//  Created by  striveliu on 14-10-9.
//  Copyright (c) 2014年 striveliu. All rights reserved.
//

#import "RootTabBarController.h"
#import "FBKVOController.h"
#import "FactoryModel.h"
#import "LSNavigationController.h"

NSInteger oldIndexSelectIndex;
@interface RootTabBarController ()
{
    
    NSInteger newSelectIndex;
    NSMutableArray *navArry;
    FBKVOController *loginObserver;
    FBKVOController *leftViewObserver;
    
    BOOL isGoBack;
}
//@property (nonatomic, strong) LoginViewController *loginVC;
@property (nonatomic, strong) UINavigationController *loginNav;
@end

@implementation RootTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
    self.delegate = self;
    isGoBack = NO;
    [self initTabViewController];
    [self initTabBarItem];
}
- (void)initTabViewController
{
    NSArray *arry = [[FactoryModel shareFactoryModel] getTabbarArrys];
    navArry = [NSMutableArray arrayWithCapacity:0];
    if(arry && arry.count>0)
    {
        for(UIViewController *vc in arry)
        {
            LSNavigationController *nav = [[LSNavigationController alloc] initWithRootViewController:vc];
            [navArry addObject:nav];
        }
    }

    self.viewControllers = navArry;
}

- (void)initTabBarItem
{
    //[[UITabBar appearance] setSelectionIndicatorImage:[UIImage imageNamed:[NSString stringWithFormat:@"TabBarItem_sel"]]];
    if(current_SYSTEMIOS<7.0)
    {
        UIImage *img = [[UIImage imageNamed:@"tabbarBG"] resizableImageWithCapInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [[UITabBar appearance] setBackgroundImage:img];
        
    }
//    NSArray *tabTitleArray = [NSArray arrayWithObjects:@"店铺",@"批发",@"订单",@"收益",@"我", nil];
    for(int i=0; i<navArry.count;i++)
    {
        UITabBarItem *tabBarItem = self.tabBar.items[i];
    
        UIImage *norimg = [UIImage imageNamed:[NSString stringWithFormat:@"TabBarItem_nomal_%d",i]];
        UIImage *selimg = [UIImage imageNamed:[NSString stringWithFormat:@"TabBarItem_light_%d",i]];
        
        [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor grayColor], UITextAttributeTextColor, nil] forState:UIControlStateNormal];
        
        [[UITabBarItem appearance] setTitleTextAttributes:
         [NSDictionary dictionaryWithObjectsAndKeys:[UIColor redColor],UITextAttributeTextColor, nil]forState:UIControlStateSelected];

        tabBarItem.imageInsets = UIEdgeInsetsMake(6, 0, -6, 0);
       // tabBarItem.title = [tabTitleArray objectAtIndex:i];     //取消显示标题
        if(current_SYSTEMIOS>=7.0)
        {
            norimg = [norimg imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            selimg = [selimg imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            tabBarItem.image = norimg;
            tabBarItem.selectedImage = selimg;
            tabBarItem.tag = i;
        }
        else
        {
            [tabBarItem setFinishedSelectedImage:selimg withFinishedUnselectedImage:norimg];
        }
    }
    [self.tabBar setTintColor:[UIColor colorWithRed:250.0/255.0 green:250.0/255.0 blue:250.0/255.0 alpha:1]];
    [self.tabBar setTintColor:[UIColor blackColor]];
    
   //` MLOG(@"tabbarHeight=%f",self.tabBar.frame.size.height);

}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
   // MLOG(@"shouldtabsel = %lu", (unsigned long)tabBarController.selectedIndex);
    DMLog(@"选中1：%lu",(unsigned long)tabBarController.selectedIndex);
    oldIndexSelectIndex = tabBarController.selectedIndex;
    return YES;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
   // MLOG(@"tabsel = %ld", (unsigned long)tabBarController.selectedIndex);
    DMLog(@"选中2：%lu",(unsigned long)tabBarController.selectedIndex);
    newSelectIndex = tabBarController.selectedIndex;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
