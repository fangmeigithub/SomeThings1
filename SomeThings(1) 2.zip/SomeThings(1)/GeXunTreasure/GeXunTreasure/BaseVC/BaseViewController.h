//
//  BaseViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@property(retain,nonatomic)UIScrollView *sc;

-(void)creatNavView :(NSString *)text :(BOOL)indexPage;
//创建右侧的导航 item
- (void)creatRightNavCarButton;

@end
