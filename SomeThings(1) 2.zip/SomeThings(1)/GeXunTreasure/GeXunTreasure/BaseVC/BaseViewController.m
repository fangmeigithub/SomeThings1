//
//  BaseViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "MethodTool.h"
#import "UIView+SDAutoLayout.h"
#import "CarViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.sc=[[UIScrollView alloc]init];
    self.sc.contentSize=CGRectMake(0, 0,self.view.frame.size.width,self.view.frame.size.height+1).size;
    self.sc.showsHorizontalScrollIndicator = NO;
    self.sc.showsVerticalScrollIndicator = NO;
    self.sc.backgroundColor = RGB(247, 247, 247, 1);
    self.sc.scrollEnabled=YES;
    [self.view addSubview:self.sc];
    self.sc.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(self.view,0).rightSpaceToView(self.view,0).bottomSpaceToView(self.view,0);
}

-(void)creatNavView :(NSString *)text :(BOOL)indexPage
{
    
    UILabel *navLabel = [MethodTool creatLabelWithAttribute:text :18  :2 :MainNavTextColor];;
    navLabel.sd_layout.widthIs(80).heightIs(20);
    self.navigationItem.titleView = navLabel;
    if (!indexPage) {
        UIButton *leftB = [[UIButton alloc]init];
        leftB.frame = CGRectMake(0, 20, 45, 50);
        UIImageView *bgImageV = [[UIImageView alloc]init];
        bgImageV.frame = CGRectMake(0, 15, 10, 17);
        bgImageV.image = [UIImage imageNamed:@"back.png"];
        [leftB addSubview:bgImageV];
        leftB.backgroundColor = [UIColor clearColor];
        [leftB addTarget:self action:@selector(cancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
        self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftB];
    }
}


//创建购物车图标
- (void)creatRightNavCarButton;
{
    UIButton *rightB = [[UIButton alloc]init];
    rightB.frame = RECT(0, 20, 45, 50, 0);
    UIImageView *bgImageV = [[UIImageView alloc]init];
    bgImageV.frame = RECT(20, 15, 29, 20 ,1);
    bgImageV.image = [UIImage imageNamed:@"goodsCar"];
    [rightB addSubview:bgImageV];
    rightB.backgroundColor = [UIColor clearColor];
    [rightB addTarget:self action:@selector(rightNavItemClick) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *goodsNumberLable = [MethodTool creatLabelWithAttribute:@"2" :13 :2 :[UIColor whiteColor]];
    goodsNumberLable.backgroundColor = [UIColor redColor];
    goodsNumberLable.frame = CGRectMake(35*NEWX, 7*NEWY, 20*NEWX, 20*NEWX);
    goodsNumberLable.layer.cornerRadius = 10*NEWX;
    goodsNumberLable.clipsToBounds = YES;
    [rightB.layer addSublayer:goodsNumberLable.layer];
    [rightB addSubview:goodsNumberLable];
    
    
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:rightB];
}
//购物车
- (void)rightNavItemClick
{
    [self.navigationController pushViewController:[[CarViewController alloc]init] animated:YES];
}

-(void)cancelButtonEvent
{
    [self.navigationController popViewControllerAnimated:YES];
}

//输入代理

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString*)text
{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    CGRect frame = textView.frame;
    int offset = frame.origin.y  - (self.view.frame.size.height - 216)+60;
    
    [UIView animateWithDuration:0.2 animations:^{
        float width = self.view.frame.size.width;
        float height = self.view.frame.size.height;
        if(offset > 0)
        {
            CGRect rect = CGRectMake(0.0f, -offset,width,height);
            self.view.frame = rect;
        }
    }];
}
-(void)textViewDidEndEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);
        self.view.frame = rect;
    }];
    [textView resignFirstResponder];
}

/**
 *  textFeild
 
 */
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);
        self.view.frame = rect;
    }];
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
    CGRect frame=[textField convertRect: textField.bounds toView:window];
    
    /*
     *  frame.origin.y;  获取的是父视图的相对坐标  需要获取在屏幕上的位置
     */
    
    int offset = frame.origin.y  - (self.view.frame.size.height - 216)+60;
    
    [UIView animateWithDuration:0.2 animations:^{
        float width = self.view.frame.size.width;
        float height = self.view.frame.size.height;
        if(offset > 0)
        {
            CGRect rect = CGRectMake(0.0f, -offset,width,height);
            self.view.frame = rect;
        }
    }];
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
}

@end
