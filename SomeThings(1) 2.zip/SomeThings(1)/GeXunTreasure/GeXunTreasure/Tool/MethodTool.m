//
//  MethodTool.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "MethodTool.h"

@implementation MethodTool

+(UILabel *)creatLabelWithAttribute :(NSString *)titleText
                               :(NSInteger )font
                               :(NSInteger)textAlignmentNumber
                               :(UIColor *)textColor
{
    UILabel *t = [[UILabel alloc] initWithFrame:CGRectZero];
    t.textColor = textColor;
    switch (textAlignmentNumber) {
        case 1:
            t.textAlignment = NSTextAlignmentLeft;
            break;
        case 2:
            t.textAlignment = NSTextAlignmentCenter;
            break;
        case 3:
            t.textAlignment = NSTextAlignmentRight;
            break;
            
        default:
            break;
    }
    
    t.opaque = YES;
    [t setFont:[UIFont fontWithName:@"Helvetica" size:font]];
    t.text = titleText;
    [t setBackgroundColor:[UIColor clearColor]];
    return t;
}

/**
 *  aa
 *
 *  @param imageName 图片名
 *
 *  @return 图片
 */
+(UIImageView *)creatImageWithAttribute:(NSString *)imageName
{
    UIImageView *ImageV =[[UIImageView alloc] initWithFrame:CGRectZero];
    if (imageName.length>0) {
        ImageV.image = [UIImage  imageNamed:imageName];
    }
    ImageV.backgroundColor = [UIColor clearColor];
    return ImageV;
}

+(UITextField *)creatTextFeild :(NSString *)placeHolder
{
    UITextField  * amiTextFeild = [[UITextField alloc]initWithFrame:CGRectZero];
    if (SYSTEMIOS7) {
        [amiTextFeild  setTintColor:MainNavTextColor];
    }
    amiTextFeild.backgroundColor = [UIColor whiteColor];
    amiTextFeild.placeholder = placeHolder;
    [amiTextFeild setValue:[UIFont boldSystemFontOfSize:15] forKeyPath:@"_placeholderLabel.font"];
    [amiTextFeild setValue:RGB(180, 180, 180, 1) forKeyPath:@"_placeholderLabel.textColor"];
    amiTextFeild.textColor = blackC;
    amiTextFeild.font = [UIFont systemFontOfSize:15];
    amiTextFeild.borderStyle = UITextBorderStyleNone;
    amiTextFeild.returnKeyType = UIReturnKeyDone;
    amiTextFeild.clearButtonMode = UITextFieldViewModeAlways;

    return amiTextFeild;
}
//button
+(UIButton *)creatButtonWithAttribute :(NSString *)titleText
                                      :(NSInteger )font
                                      :(UIColor *)bgColor
                                      :(UIColor *)textColor
{
    UIButton *button=[[UIButton alloc]initWithFrame:CGRectZero];
    [button setBackgroundColor:bgColor];
    [button setTitle:titleText forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:font]];
    [button setTitleColor:textColor forState:UIControlStateNormal];
    return button;
}
+(void)shakeView:(UIView*)viewToShake
{
    CGFloat t =8.0;
    CGAffineTransform translateRight  =CGAffineTransformTranslate(CGAffineTransformIdentity, t,0.0);
    CGAffineTransform translateLeft   =CGAffineTransformTranslate(CGAffineTransformIdentity,-t,0.0);
    
    viewToShake.transform = translateLeft;
    
    [UIView animateWithDuration:0.07 delay:0.0 options:UIViewAnimationOptionAutoreverse|UIViewAnimationOptionRepeat animations:^{
        [UIView setAnimationRepeatCount:2.0];
        viewToShake.transform = translateRight;
    } completion:^(BOOL finished){
        if(finished){
            [UIView animateWithDuration:0.05 delay:0.0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
                viewToShake.transform =CGAffineTransformIdentity;
            } completion:NULL];
        }
    }];
}
+(void)setUserDefaults :(id)obj :(NSString*)key;
{
    if (!obj) {
        return;
    }
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] setObject:obj forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(id)getUserDefaults :(NSString*)key;
{
    return [[NSUserDefaults standardUserDefaults]objectForKey:key];
}

+ (NSString *) cleanData:(id)value {
    
    if (value == nil || value == NULL)
    {
        return @"";
    }
    if ([value isKindOfClass:[NSNull class]]) {
        
        return @"";
    }
    if ([value isKindOfClass:[NSString class]])
    {
        return value;
    }
    if ([value isKindOfClass:[NSNumber class]])
    {
        return [value stringValue];
    }
    return @"";
}


@end
