//
//  SecondViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PersonViewController.h"
#import "PersonTableViewCell.h"
#import "AboutViewController.h"

@interface PersonViewController ()
<UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate>
{
    UITableView *Tb;
    
    NSArray *cellLeftTextArray;
    UIImageView *headHeadBgImageV;
}
@end

@implementation PersonViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"我的" :YES];
     self.navigationController.interactivePopGestureRecognizer.delegate = self;
    cellLeftTextArray = [[NSArray alloc]initWithObjects:@"修改密码",@"关        于",@"退        出", nil];
    
    [self initSub];
    
}

- (void)initSub
{

    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    self.sc.scrollEnabled = NO;
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,0);
    Tb.tableHeaderView = [[UIView alloc]initWithFrame:RECT(0, 0, 320, 160, 1)];

    //头像背景
    headHeadBgImageV = [MethodTool creatImageWithAttribute:@"myHeadImage.png"];
    [Tb addSubview:headHeadBgImageV];
    headHeadBgImageV.sd_layout.leftSpaceToView(Tb,0).topSpaceToView(Tb,0).widthIs(Scale_X(320)).heightIs(Scale_Y(160));
    
    // 头像
    UIImageView *headHeadImageV = [MethodTool creatImageWithAttribute:@"defaultHeadImage.png"];
    [headHeadBgImageV addSubview:headHeadImageV];
    headHeadImageV.sd_layout
    .centerXEqualToView(headHeadBgImageV)
    .topSpaceToView(headHeadBgImageV,Scale_Y(20))
    .widthIs(Scale_X(80))
    .heightEqualToWidth();
    headHeadImageV.sd_cornerRadiusFromHeightRatio = @(0.5);
    
    
    
    UILabel *nameLabel = [MethodTool creatLabelWithAttribute:@"姓名：张晓晓" :13 :2 :[UIColor whiteColor]];
    [headHeadBgImageV addSubview:nameLabel];
    nameLabel.sd_layout.centerXEqualToView(headHeadBgImageV).topSpaceToView(headHeadImageV,Scale_Y(7)).widthIs(Scale_X(100)).heightIs(Scale_Y(15));
    
    
    UILabel *zhanghaoLabel = [MethodTool creatLabelWithAttribute:@"账号:ADADJDAJDJ00" :13 :2 :[UIColor whiteColor]];
    [headHeadBgImageV addSubview:zhanghaoLabel];
    zhanghaoLabel.sd_layout.centerXEqualToView(headHeadBgImageV).topSpaceToView(nameLabel,Scale_Y(6)).widthIs(Scale_X(140)).heightIs(Scale_Y(15));
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Scale_Y(45);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return cellLeftTextArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    PersonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[PersonTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.leftTextLabel.text =[cellLeftTextArray objectAtIndex:indexPath.row];
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    switch (indexPath.row) {
        case 0:
            
            break;
        case 1:
            [self.navigationController pushViewController:[[AboutViewController alloc]init] animated:YES];
            break;
        case 2:
            
            break;
            
        default:
            break;
    }
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat offsetY = scrollView.contentOffset.y;
    
    if (offsetY < 0) {
        headHeadBgImageV.frame = CGRectMake(offsetY/2, offsetY, WIDTH - offsetY, Scale_Y(160) - offsetY);  // 修改头部的frame值就行了
    }
}
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if (self.navigationController.viewControllers.count == 1)
    {
        return NO;
    }
    else{
        return YES;
    }
}

@end
