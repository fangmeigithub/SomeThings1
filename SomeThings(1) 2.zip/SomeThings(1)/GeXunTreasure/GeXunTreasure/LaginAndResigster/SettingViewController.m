//
//  SettingViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SettingViewController.h"

@interface SettingViewController ()
{
    UIView *iPView,*portView;
    UITextField *ipTF,*portTF;
}
@end

@implementation SettingViewController
 
- (void)viewDidLoad {
    [super viewDidLoad];
     self.navigationController.navigationBar.hidden =NO;
    [super creatNavView:@"设置端口" :NO];
    [self initSubV];
   
    
}

- (void)initSubV
{
    iPView = [UIView new];
    iPView.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:iPView];
    iPView.sd_layout.leftSpaceToView(self.sc,20).topSpaceToView(self.sc,90).rightSpaceToView(self.sc,20).heightIs(50);
    
    UILabel *ipLabel = [MethodTool creatLabelWithAttribute:@"服务器IP" :15 :1 :GrayTextColor];
    [iPView addSubview:ipLabel];
    ipLabel.sd_layout.leftSpaceToView(iPView,10).topSpaceToView(iPView,15).widthIs(60).heightIs(20);
    
    ipTF = [MethodTool creatTextFeild:@"1982.333.1.1.1"];
    [iPView addSubview:ipTF];
    ipTF.delegate = self;
    UIEdgeInsets sg = UIEdgeInsetsMake(15, 90, 15, 15);
    ipTF.sd_layout.spaceToSuperView(sg);
    
    
    portView = [UIView new];
    portView.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:portView];
    portView.sd_layout.leftEqualToView(iPView).topSpaceToView(iPView,10).rightEqualToView(iPView).heightRatioToView(iPView,1);
    
    UILabel *portLabel = [MethodTool creatLabelWithAttribute:@"端口号" :15 :1 :GrayTextColor];
    [portView addSubview:portLabel];
    portLabel.sd_layout.leftSpaceToView(portView,10).topSpaceToView(portView,15).widthIs(60).heightIs(20);
    
    portTF = [MethodTool creatTextFeild:@"2014"];
    [portView addSubview:portTF];
    portTF.delegate = self;
    UIEdgeInsets sg1 = UIEdgeInsetsMake(15, 90, 15, 15);
    portTF.sd_layout.spaceToSuperView(sg1);
    
    UIButton *loginButton = [MethodTool creatButtonWithAttribute:@"保存" :16 :RGB(63, 155, 248, 1) :[UIColor whiteColor]];
    [self.sc addSubview:loginButton];
    loginButton.sd_layout.leftEqualToView(portView).topSpaceToView(portView,40).rightEqualToView(portView).heightIs(45);
    loginButton.layer.cornerRadius = 3;
    [loginButton addTarget:self action:@selector(save) forControlEvents:UIControlEventTouchUpInside];
}

- (void)save
{
    
}

@end
