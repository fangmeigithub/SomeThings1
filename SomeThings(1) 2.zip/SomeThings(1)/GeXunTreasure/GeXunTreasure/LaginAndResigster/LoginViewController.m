//
//  LoginViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "LoginViewController.h"
#import "LMComBoxView.h"
#import "UIScrollView+Touch.h"
#import "SettingViewController.h"
#import "RootTabBarController.h"


@interface LoginViewController ()
<LMComBoxViewDelegate>{
    UIView *nameBgView;
    UIView *passWordBgView;
    
    UITextField *nameTF;
    UITextField *passWordTF;
    
    UIImageView *rememberPassWordImageV;
    UIImageView *autoLoginImageV;
    
    BOOL rememberPW;
    BOOL autoLogin;
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"登录" :YES];
    
    rememberPW = [[MethodTool getUserDefaults:@"rememberPW"] boolValue];
    autoLogin = [[MethodTool getUserDefaults:@"autoLogin"] boolValue];
    
    
    
    NSLog(@"Ysdasd:%@",autoLogin== YES?@"AT":@"NAT");
    [self initSubV];
    
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = YES;
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    
    self.navigationController.navigationBar.hidden = NO;
    [MethodTool setUserDefaults:[NSNumber numberWithBool:autoLogin] :@"autoLogin"];
    [MethodTool setUserDefaults:[NSNumber numberWithBool:rememberPW] :@"rememberPW"];
}

-(void)cancelButtonEvent
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
// 设置
-(void)setting
{
    [self.navigationController pushViewController:[SettingViewController new] animated:YES];
}

- (void)initSubV
{
    UIImageView *bgImaeV = [MethodTool creatImageWithAttribute:@"loginBg.png"];
    [self.view addSubview:bgImaeV];
    bgImaeV.sd_layout.leftSpaceToView(self.view,0).rightSpaceToView(self.view,0).topSpaceToView(self.view,0).bottomSpaceToView(self.view,0);
    
    self.sc.backgroundColor = [UIColor clearColor];
    [self.view bringSubviewToFront:self.sc];


    UIButton *rightButton = [[UIButton alloc]init];
    UIImageView *bgImageV = [[UIImageView alloc]init];
    bgImageV.frame = CGRectMake(20*NEWX, 12*NEWY, 20.5*NEWX, 20.5*NEWX);;
    bgImageV.image = [UIImage imageNamed:@"setting.png"];
    [rightButton addSubview:bgImageV];
    rightButton.backgroundColor = [UIColor clearColor];
    [rightButton addTarget:self action:@selector(setting) forControlEvents:UIControlEventTouchUpInside];
    [self.sc addSubview:rightButton];
    rightButton.sd_layout.topSpaceToView(self.sc,Scale_Y(20)).rightSpaceToView(self.sc,Scale_X(5)).widthIs(Scale_X(50)).heightIs(Scale_X(50));
    
    //logo图
    UIImageView *logoImageV = [MethodTool creatImageWithAttribute:@"logo"];
    [self.sc addSubview:logoImageV];
    logoImageV.sd_layout.centerXEqualToView(self.sc).topSpaceToView(self.sc,Scale_Y(60)).widthIs(Scale_X(213)).heightIs(Scale_Y(67));
    
    LMComBoxView *comBox = [[LMComBoxView alloc]initWithFrame:CGRectMake(Scale_X(20), logoImageV.bottom+Scale_Y(112), WIDTH-Scale_X(40), Scale_Y(40))];
    comBox.backgroundColor = [UIColor whiteColor];
    comBox.arrowImgName = @"xiala.png";
    comBox.titlesList = [NSMutableArray arrayWithArray:@[@"内部",@"外部"]];
    comBox.delegate = self;
    comBox.supView = self.view;
    [comBox defaultSettings];
    
    comBox.tag = 1000 ;//
    [self.sc addSubview:comBox];
    //comBox.sd_layout.leftSpaceToView(self.sc,20).topSpaceToView(logoImageV,60).rightSpaceToView(self.sc,20).heightIs(40);
    
    
    nameBgView = [UIView new];
    nameBgView.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:nameBgView];
    nameBgView.sd_layout.leftEqualToView(comBox).topSpaceToView(comBox,Scale_Y(10)).rightEqualToView(comBox).heightIs(Scale_Y(40));
    
    
    nameTF = [MethodTool creatTextFeild:@"用户名"];
    [nameBgView addSubview:nameTF];
    nameTF.delegate = self;
    UIEdgeInsets sg = UIEdgeInsetsMake(10, 15, 10, 15);
    nameTF.sd_layout.spaceToSuperView(sg);
    
    
    passWordBgView = [UIView new];
    passWordBgView.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:passWordBgView];
    passWordBgView.sd_layout.leftEqualToView(comBox).topSpaceToView(nameBgView,Scale_Y(10)).rightEqualToView(comBox).heightRatioToView(nameBgView,1);
    
    passWordTF = [MethodTool creatTextFeild:@"密码"];
    [passWordBgView addSubview:passWordTF];
    passWordTF.delegate = self;
    UIEdgeInsets sg1 = UIEdgeInsetsMake(10, 15, 10, 15);
    passWordTF.sd_layout.spaceToSuperView(sg1);
    
    //记住密码
    
    UIButton *rememberB = [UIButton new];
    [self.sc addSubview:rememberB];
    rememberB.selected = rememberPW;
    rememberB.sd_layout.leftEqualToView(passWordBgView).topSpaceToView(passWordBgView,0).widthIs(Scale_X(50)).heightIs(Scale_Y(40));
    [rememberB addTarget:self action:@selector(rememberClick:) forControlEvents:UIControlEventTouchUpInside];
    
    rememberPassWordImageV = [MethodTool creatImageWithAttribute:rememberPW?@"selectKuang.png":@"onSelectKuang.png"];
    [self.sc addSubview:rememberPassWordImageV];
    rememberPassWordImageV.sd_layout.leftSpaceToView(self.sc,Scale_X(25)).topSpaceToView(passWordBgView,Scale_Y(10)).widthIs(Scale_X(15)).heightIs(Scale_X(15));
    
    UILabel *rememberLabel = [MethodTool creatLabelWithAttribute:@"记住密码" :14 :1 :[UIColor whiteColor]];
    [self.sc addSubview:rememberLabel];
    rememberLabel.sd_layout.leftSpaceToView(rememberPassWordImageV,Scale_X(5)).topEqualToView(rememberPassWordImageV).widthIs(Scale_X(80)).heightIs(Scale_Y(15));
    
    //自动登录
    
    UILabel *autoLoginLabel = [MethodTool creatLabelWithAttribute:@"自动登录" :14 :1 :[UIColor whiteColor]];
    [self.sc addSubview:autoLoginLabel];
    autoLoginLabel.sd_layout.rightEqualToView(passWordBgView).topEqualToView(rememberPassWordImageV).widthIs(Scale_X(60)).heightIs(Scale_Y(15));
    
    
    autoLoginImageV = [MethodTool creatImageWithAttribute:autoLogin?@"selectKuang.png":@"onSelectKuang.png"];
    [self.sc addSubview:autoLoginImageV];
    autoLoginImageV.sd_layout.rightSpaceToView(autoLoginLabel,Scale_X(5)).topEqualToView(autoLoginLabel).widthIs(Scale_X(15)).heightIs(Scale_X(15));
    
    UIButton *aotuLoginB = [UIButton new];
    [self.sc addSubview:aotuLoginB];
    aotuLoginB.selected = autoLogin;
    aotuLoginB.sd_layout.rightSpaceToView(autoLoginLabel,0).topSpaceToView(passWordBgView,0).widthIs(Scale_X(50)).heightIs(Scale_X(40));
    [aotuLoginB addTarget:self action:@selector(aotuLogin:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *loginButton = [MethodTool creatButtonWithAttribute:@"登录" :16 :RGB(63, 155, 248, 1) :[UIColor whiteColor]];
    [self.sc addSubview:loginButton];
    loginButton.sd_layout.leftEqualToView(passWordBgView).topSpaceToView(passWordBgView,Scale_Y(80)).rightEqualToView(passWordBgView).heightIs(Scale_Y(40));
    loginButton.layer.cornerRadius = 3;
    [loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIView *bottomView   = [UIView new];
    bottomView.backgroundColor = RGB(30, 43, 60, 1);
    [self.view addSubview:bottomView];
    bottomView.sd_layout.leftSpaceToView(self.view,0).rightSpaceToView(self.view,0).bottomSpaceToView(self.view,0).heightIs(Scale_Y(50));
    
    
    NSArray *methodArray = [NSArray arrayWithObjects:@"rememberClick",@"regester", nil];
    for (int i = 0; i<2; i++) {
        UIButton *forgetButton = [MethodTool creatButtonWithAttribute:i==0?@"忘记密码":@"注册" :15 :[UIColor clearColor] :loginTextColor];
        [bottomView addSubview:forgetButton];
        if (i==0) {
            forgetButton.sd_layout.leftSpaceToView(bottomView,0).topSpaceToView(bottomView,0).widthRatioToView(bottomView,0.5).heightRatioToView(bottomView,1);
        }
        else{
            forgetButton.sd_layout.rightSpaceToView(bottomView,0).topSpaceToView(bottomView,0).widthRatioToView(bottomView,0.5).heightRatioToView(bottomView,1);
        }
        
        SEL clickMethod = NSSelectorFromString([methodArray objectAtIndex:i]);
        [forgetButton addTarget: self action:clickMethod forControlEvents:UIControlEventTouchUpInside];
    }

    
    UIView *lineV1 = [UIView new];
    lineV1.backgroundColor = RGB(35, 60, 79, 1);
    [bottomView addSubview:lineV1];
    lineV1.sd_layout.centerXEqualToView(bottomView).centerYEqualToView(bottomView).heightRatioToView(bottomView,1).widthIs(0.8);
    

}
#pragma mark -LMComBoxViewDelegate
-(void)selectAtIndex:(NSInteger)index inCombox:(LMComBoxView *)_combox
{
    NSLog(@"下拉%ld %@",(long)index,_combox);
    
    
}

//记住密码
-(void)rememberClick :(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        rememberPassWordImageV.image = [UIImage imageNamed:@"selectKuang"];
        rememberPW = YES;
        
    } else {
        rememberPassWordImageV.image = [UIImage imageNamed:@"onSelectKuang"];
        rememberPW = NO;
    }
    
}

//自动登录
-(void)aotuLogin :(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        autoLoginImageV.image = [UIImage imageNamed:@"selectKuang"];
        autoLogin = YES;
    } else {
        autoLoginImageV.image = [UIImage imageNamed:@"onSelectKuang"];
        autoLogin = NO;
    }
}

//注册
-(void)regester
{
    
};


//忘记密码
-(void)forgetPassWord
{
    
}


//登录
-(void)login
{
//    if ([nameTF.text stringByReplacingOccurrencesOfString:@" " withString:@""].length==0) {
//        [MethodTool shakeView:nameBgView];
//    }
//    else if([passWordTF.text stringByReplacingOccurrencesOfString:@" " withString:@""].length ==0)
//    {
//        [MethodTool shakeView:passWordBgView];
//    }
//    else{
//        [self setTextFeilSatus];
    
        RootTabBarController *rootBar = [[RootTabBarController alloc]init];
        //rootBar.view.frame = self.window.bounds;
        self.view.window.rootViewController =  rootBar;
 //   }
}
-(void)setTextFeilSatus{
    [nameTF resignFirstResponder];
    [passWordTF resignFirstResponder];
}



@end
