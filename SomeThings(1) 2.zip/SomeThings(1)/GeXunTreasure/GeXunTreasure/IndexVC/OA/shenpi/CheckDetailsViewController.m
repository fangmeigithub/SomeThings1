//
//  CheckDetailsViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CheckDetailsViewController.h"

@interface CheckDetailsViewController ()
<UIAlertViewDelegate>
{
    NSArray *leftTitleArray;
    NSArray *rightTitleArray;
    
    
}
@end

@implementation CheckDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:self.titleName :NO];
    self.anFinish = YES;
    
    leftTitleArray = [[NSArray alloc]initWithObjects:@"审批编号:",@"所在部门:",@"请假类型:",@"开始时间:",@"结束时间:",@"请假天数:",@"请假事由:",@"申请时间:", nil];
    rightTitleArray = [[NSArray alloc]initWithObjects:@"0022222",@"开发部",@"事假",@"2016-10-90",@"2016-10-90",@"1天",@"办理居住证",@"2016-04-12 12:45:38", nil];
    [self initSub];
}


-(void)initSub
{
    UIView *viewBgView = [UIView new];
    viewBgView.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:viewBgView];
    
    //anFinish 是否是未处理的事务
    if (self.anFinish) {
        
        viewBgView.sd_layout.leftSpaceToView(self.sc,10).topSpaceToView(self.sc,74).rightSpaceToView(self.sc,10).bottomSpaceToView(self.sc,60);
        
        //底部背景
        UIView *bottomView = [UIView new];
        bottomView.backgroundColor = [UIColor whiteColor];
        [self.sc addSubview:bottomView];
        bottomView.sd_layout.leftSpaceToView(self.sc,0).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,0).heightIs(50);
        
        //最上面的线
        UIView *lineV = [UIView new];
        lineV.backgroundColor = ViewlineColor;
        [bottomView addSubview:lineV];
        lineV.sd_layout.leftSpaceToView(bottomView,0).rightSpaceToView(bottomView,0).bottomSpaceToView(bottomView,49.2).heightIs(0.8);
        
        
         UIView *rejectV = [UIView new];
         [bottomView addSubview:rejectV];
         rejectV.sd_layout.centerXEqualToView(bottomView).topSpaceToView(bottomView,0).widthRatioToView(bottomView,0.33).heightIs(50);
         
         UIView *sureV =[UIView new];
         [bottomView addSubview:sureV];
         sureV.sd_layout.rightSpaceToView(rejectV,0).topSpaceToView(bottomView,0).widthRatioToView(bottomView,0.33).heightIs(50);
         
         UIView *cancalV = [UIView new];
         [bottomView addSubview:cancalV];
         cancalV.sd_layout.leftSpaceToView(rejectV,0).topSpaceToView(bottomView,0).widthRatioToView(bottomView,0.33).heightIs(50);
        
         UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(sure:)];
         UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(reject:)];
         UITapGestureRecognizer *tapGe3 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cancal:)];
    
         [sureV addGestureRecognizer:tapGe1];
         [rejectV addGestureRecognizer:tapGe2];
         [cancalV addGestureRecognizer:tapGe3];

        [self creatBottowSubView:rejectV :0];
        [self creatBottowSubView:sureV :1];
        [self creatBottowSubView:cancalV :2];

    }
    else{
        viewBgView.sd_layout.leftSpaceToView(self.sc,10).topSpaceToView(self.sc,74).rightSpaceToView(self.sc,10).bottomSpaceToView(self.sc,10);
    }
    
    
    UILabel *titleLabel = [MethodTool creatLabelWithAttribute:@"等待项目经理审批" :13 :2 :self.anFinish?NEWSTITLECOLOR:loginTextColor];
    [viewBgView addSubview:titleLabel];
    titleLabel.sd_layout.centerXEqualToView(viewBgView).topSpaceToView(viewBgView,20).widthIs(120);
    
    
    for (int i = 0; i<8; i++) {
        
        UILabel *leftLabel = [MethodTool creatLabelWithAttribute:@"" :13 :1 :NEWSCONTEXTCOLOR];
        leftLabel.text = [leftTitleArray objectAtIndex:i];
        [viewBgView addSubview:leftLabel];
        leftLabel.sd_layout.leftSpaceToView(viewBgView,10).topSpaceToView(viewBgView,60+23*i).widthIs(60).heightIs(20);
        
        UILabel *rightLabel = [MethodTool creatLabelWithAttribute:[rightTitleArray objectAtIndex:i] :13 :1 :NEWSCONTEXTCOLOR];
        [viewBgView addSubview:rightLabel];
        rightLabel.sd_layout.leftSpaceToView(viewBgView,70).topSpaceToView(viewBgView,60+23*i).rightSpaceToView(viewBgView,10).heightIs(20);
        
    }
    
}
/**
 *  创建下面三个热区的子试图
 *
 *  @param fatherView 父试图
 *  @param index      下表顺序
 */
-(void)creatBottowSubView :(UIView *)fatherView :(NSInteger )index{
    
     NSArray *textArray = [[NSArray alloc]initWithObjects:@"同意",@"拒绝",@"转交", nil];
    
    //竖线
    UIView *lineV1 = [UIView new];
    lineV1.backgroundColor = ViewlineColor;
    [fatherView addSubview:lineV1];
    
    UILabel *centerRect = [UILabel new];
    [fatherView addSubview:centerRect];
    centerRect.sd_layout.centerXEqualToView(fatherView).topSpaceToView(fatherView,15).widthIs(0.8).heightIs(20);
    
    UIImageView *imagev = [MethodTool creatImageWithAttribute:[NSString stringWithFormat:@"shenpi%ld.png",(long)index]];
    [fatherView addSubview:imagev];
    
    UILabel *textLabel = [MethodTool creatLabelWithAttribute:[textArray objectAtIndex:index] :14 :2 :NEWSTITLECOLOR];
    [fatherView addSubview:textLabel];
    
    lineV1.sd_layout.rightSpaceToView(fatherView,0).topSpaceToView(fatherView,0).bottomSpaceToView(fatherView,0).widthIs(0.8);
    textLabel.sd_layout.leftSpaceToView(centerRect,1).topSpaceToView(fatherView,15).widthIs(40).heightIs(20);
    imagev.sd_layout.rightSpaceToView(centerRect,0).topEqualToView(textLabel).widthIs(20).heightIs(20);
    
}

//同意
- (void)sure:(UITapGestureRecognizer *)sender
{
    UIAlertView  * customAlertView = [[UIAlertView alloc] initWithTitle:@"请输入理由（非必填）" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定",  nil];
    [customAlertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
    UITextField *reasonTextF = [customAlertView textFieldAtIndex:0];
    customAlertView.delegate = self;
    reasonTextF.placeholder = @"";
    [customAlertView show];
    
}
//拒绝
- (void)reject:(UITapGestureRecognizer *)sender
{
   
}
//转交
- (void)cancal:(UITapGestureRecognizer *)sender
{
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    
    if (interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
        //zuo
    }
    if (interfaceOrientation==UIInterfaceOrientationLandscapeRight) {
        //you
    }
    if (interfaceOrientation==UIInterfaceOrientationPortrait) {
        //shang
    }
    if (interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
        //xia
    }
    return YES;
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    UITextField *reasonTextF = [alertView textFieldAtIndex:0];
    [reasonTextF resignFirstResponder];
    if (buttonIndex == alertView.firstOtherButtonIndex) {
        
    }
}


@end
