//
//  CheckViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CheckViewController.h"
#import "CheckViewTableViewCell.h"
#import "ChineseInclude.h"
#import "PinYinForObjc.h"
#import "CheckDetailsViewController.h"



@interface CheckViewController ()
<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIBarPositioningDelegate>
{
    UIButton *leftButton,*rightButton;
    UITableView *Tb;
    BOOL haveRead;
    
    NSArray *titleArray;
    
    NSMutableArray *dataArray;
    NSMutableArray *searchResults;
    UISearchBar *mySearchBar;
    UISearchDisplayController *searchDisplayController;
}
@end

@implementation CheckViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    haveRead = NO;

   [super creatNavView:@"审批" :NO];
    [self creatSubV];

    
    mySearchBar = [[UISearchBar alloc] init];
    mySearchBar.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,115).rightSpaceToView(self.sc,0).heightIs(35);
    mySearchBar.placeholder = @"搜索";
    mySearchBar.delegate =self;
    mySearchBar.layer.cornerRadius=5;
    mySearchBar.layer.masksToBounds=YES;
    [mySearchBar setBackgroundImage:[UIImage imageNamed:@"searchBg"]];
    [mySearchBar setSearchFieldBackgroundImage:[UIImage imageNamed:@"searchBg"] forState:UIControlStateNormal];

    [self.sc addSubview:mySearchBar];
    
    searchDisplayController = [[UISearchDisplayController alloc]initWithSearchBar:mySearchBar contentsController:self];
    searchDisplayController.active = NO;
    searchDisplayController.searchResultsDataSource = self;
    searchDisplayController.searchResultsDelegate = self;
    
    
    Tb.tableHeaderView = mySearchBar;
    dataArray = [@[ @"张三请假条",
                    @"李四报销单",
                    @"王五的申请单",]mutableCopy];
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    searchDisplayController.active = NO;
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
   
}
-(void)creatSubV
{
    for (int i = 0; i<2; i++) {
        UIButton  *statusChangeButton = [MethodTool creatButtonWithAttribute:i==0?@"待审批":@"已审批"
                                                                            :16
                                                                            :i==0?MainNavTextColor:RGB(210, 210, 210, 1)
                                                                            :i==0?[UIColor whiteColor]:RGB(124, 129, 135, 1)];
        statusChangeButton.tag = 100+i;
        [self.sc addSubview:statusChangeButton];
        if (i==0) {
            statusChangeButton.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).widthRatioToView(self.sc,0.5).heightIs(35);
        }
        else{
            statusChangeButton.sd_layout.rightSpaceToView(self.sc,0).topSpaceToView(self.sc,64).widthRatioToView(self.sc,0.5).heightIs(35);
        }
        [statusChangeButton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,10).topSpaceToView(self.sc,115).rightSpaceToView(self.sc,10).bottomSpaceToView(self.sc,10);
    
}


-(void)buttonClick :(UIButton *)sender
{
    for (UIButton *bu in self.sc.subviews) {
        if (bu.tag>99) {
            if ([bu isEqual:sender]) {
                [sender setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [sender setBackgroundColor:MainNavTextColor];
            }
            else{
                [bu setTitleColor:RGB(124, 129, 135, 1) forState:UIControlStateNormal];
                [bu setBackgroundColor:RGB(210, 210, 210, 1)];
                
            }
        }
    }
    switch (sender.tag) {
        case 100://已读
            haveRead = NO;
            [Tb reloadData];
            break;
        case 101://未读
            haveRead = YES;
            [Tb reloadData];
            break;
            
        default:
            break;
    }
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return searchResults.count;
    }
    else {
        return dataArray.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    CheckViewTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[CheckViewTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    if (tableView == self.searchDisplayController.searchResultsTableView) {
       cell.titleLabel.text = searchResults[indexPath.row];
    }
    else {
        cell.titleLabel.text = dataArray[indexPath.row];
    }
    cell.tag = indexPath.row;
    cell.haveRead = haveRead;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    CheckDetailsViewController *CheckDetailsVC = [[CheckDetailsViewController alloc]init];
    CheckDetailsVC.titleName = [dataArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:CheckDetailsVC animated:YES];
}

#pragma UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    searchResults = [[NSMutableArray alloc]init];
    if (mySearchBar.text.length>0&&![ChineseInclude isIncludeChineseInString:mySearchBar.text]) {
        for (int i=0; i<dataArray.count; i++) {
            if ([ChineseInclude isIncludeChineseInString:dataArray[i]]) {
                NSString *tempPinYinStr = [PinYinForObjc chineseConvertToPinYin:dataArray[i]];
                NSRange titleResult=[tempPinYinStr rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
                if (titleResult.length>0) {
                    [searchResults addObject:dataArray[i]];
                }
            }
            else {
                NSRange titleResult=[dataArray[i] rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
                if (titleResult.length>0) {
                    [searchResults addObject:dataArray[i]];
                }
            }
        }
    } else if (mySearchBar.text.length>0&&[ChineseInclude isIncludeChineseInString:mySearchBar.text]) {
        for (NSString *tempStr in dataArray) {
            NSRange titleResult=[tempStr rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
            if (titleResult.length>0) {
                [searchResults addObject:tempStr];
            }
        }
    }
    
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
       cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
//       cell.contentView.sd_layout.rightSpaceToView(cell.contentView.superview,0).topSpaceToView(cell.contentView.superview,cell.contentView.origin.y).widthIs(cell.contentView.size.width).heightIs(cell.contentView.size.height);
//        [cell.contentView updateLayout];
    } completion:^(BOOL finished) {
        ;
    }];
    
    //UITableViewWrapperView
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    for(id cc in [searchBar.subviews[0] subviews])
    {
        if([cc isKindOfClass:[UIButton class]])
        {
            UIButton *btn = (UIButton *)cc;
            [btn setTitle:@"取消"  forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
    }
}
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [UIApplication sharedApplication].statusBarStyle =  UIStatusBarStyleDefault;
    return YES;
}
- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
     [UIApplication sharedApplication].statusBarStyle =  UIStatusBarStyleLightContent;
    return YES;
}

- (void)cancelButtonEvent
{
    [self.navigationController popViewControllerAnimated:YES];
}



@end
