//
//  OAViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OAViewController.h"
#import "PublicNoticeViewController.h"
#import "CheckViewController.h"
#import "WorkLogViewController.h"

@interface OAViewController ()

@end

@implementation OAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"OA办公" :NO];
    [self creatSubV];
}

-(void)creatSubV
{
    
    
   
    UIImageView *imageV1 = [MethodTool creatImageWithAttribute:@"OA1 (1)"];
    imageV1.userInteractionEnabled = YES;
    [self.sc addSubview:imageV1];
    UIImageView *imageV2 = [MethodTool creatImageWithAttribute:@"OA1 (2)"];
    imageV2.userInteractionEnabled = YES;
    [self.sc addSubview:imageV2];
    UIImageView *imageV3 = [MethodTool creatImageWithAttribute:@"OA1 (3)"];
    imageV3.userInteractionEnabled = YES;
    [self.sc addSubview:imageV3];
    UIImageView *imageV4 = [MethodTool creatImageWithAttribute:@"OA1 (4)"];
    imageV4.userInteractionEnabled = YES;
    [self.sc addSubview:imageV4];
    
    
    imageV1.sd_layout.leftSpaceToView(self.sc,Scale_X(40)).topSpaceToView(self.sc,(64+Scale_Y(40))).widthRatioToView(self.sc,0.3).heightEqualToWidth();
    imageV2.sd_layout.topEqualToView(imageV1).rightSpaceToView(self.sc,Scale_Y(40)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,Scale_Y(45)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV4.sd_layout.topEqualToView(imageV3).rightEqualToView(imageV2).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    
    
    
    
    UILabel *label1 = [MethodTool creatLabelWithAttribute:@"公告" :15 :2 :blackC];
    [self.sc addSubview:label1];
    UILabel *label2 = [MethodTool creatLabelWithAttribute:@"审批" :15 :2 :blackC];       
    [self.sc addSubview:label2];
    UILabel *label3 = [MethodTool creatLabelWithAttribute:@"签到" :15 :2 :blackC];
    [self.sc addSubview:label3];
    UILabel *label4 = [MethodTool creatLabelWithAttribute:@"日志" :15 :2 :blackC];
    [self.sc addSubview:label4];
    
    
    label1.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,Scale_Y(8)).widthRatioToView(imageV1,1).heightIs(Scale_Y(30));
    label2.sd_layout.topEqualToView(label1).rightEqualToView(imageV2).widthRatioToView(label1,1).heightRatioToView(label1,1);
    label3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV3,Scale_Y(8)).widthRatioToView(label1,1).heightRatioToView(label1,1);
    label4.sd_layout.topEqualToView(label3).rightEqualToView(imageV2).widthRatioToView(label1,1).heightRatioToView(label1,1);
    
    
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView1:)];
    UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView2:)];
    UITapGestureRecognizer *tapGe3 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView3:)];
    UITapGestureRecognizer *tapGe4 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView4:)];
    
    [imageV1 addGestureRecognizer:tapGe1];
    [imageV2 addGestureRecognizer:tapGe2];
    [imageV3 addGestureRecognizer:tapGe3];
    [imageV4 addGestureRecognizer:tapGe4];
}


//公告
- (void)topAImageView1:(UITapGestureRecognizer *)sender
{
    [self.navigationController pushViewController:[PublicNoticeViewController new] animated:YES];
    
}
//审批
- (void)topAImageView2:(UITapGestureRecognizer *)sender
{
     [self.navigationController pushViewController:[CheckViewController new] animated:YES];
}
//签到
- (void)topAImageView3:(UITapGestureRecognizer *)sender
{
    
}
//日志
- (void)topAImageView4:(UITapGestureRecognizer *)sender
{
    [self.navigationController pushViewController:[WorkLogViewController new] animated:YES];
}
@end
