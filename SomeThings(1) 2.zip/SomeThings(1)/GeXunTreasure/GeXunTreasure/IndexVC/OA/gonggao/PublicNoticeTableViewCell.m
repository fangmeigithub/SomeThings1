//
//  PublicNoticeTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PublicNoticeTableViewCell.h"

@implementation PublicNoticeTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(247, 247, 247, 1);
        [self.contentView addSubview:bgView];
        
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,0)
        .topSpaceToView(self.contentView,0)
        .rightSpaceToView(self.contentView,0)
        .bottomSpaceToView(self.contentView,5);
        
        self.titleLabel = [MethodTool creatLabelWithAttribute:@"2016年假日安排表" :15 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.titleLabel];
        self.titleLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .topSpaceToView(bgView,7)
        .rightSpaceToView(bgView,5)
        .heightIs(15);
        
        
        self.contextLabel = [MethodTool creatLabelWithAttribute:@"根据国家规定：我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司我公司" :14 :1 :NEWSCONTEXTCOLOR];
        [bgView addSubview:self.contextLabel];
        self.contextLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .topSpaceToView(self.titleLabel,3)
        .rightSpaceToView(bgView,5)
        .heightRatioToView(self.titleLabel,1);
        
        
        self.dateLabel = [MethodTool creatLabelWithAttribute:@"2016-12-10 08:10:45" :13 :3 :NEWSCONTEXTCOLOR];
        [bgView addSubview:self.dateLabel];
        self.dateLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .rightSpaceToView(bgView,10)
        .bottomSpaceToView(bgView,5)
        .heightRatioToView(self.titleLabel,1);
        
    }
    return self;
}
-(void) setHaveRead:(BOOL)haveRead
{
    self.titleLabel.textColor = haveRead?NEWSCONTEXTCOLOR:NEWSTITLECOLOR;
}
@end
