//
//  PublicNoticeViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "PublicNoticeViewController.h"
#import "PublicNoticeTableViewCell.h"

@interface PublicNoticeViewController ()
<UITableViewDataSource,UITableViewDelegate>
{
    UIButton *leftButton,*rightButton;
    UITableView *Tb;
    BOOL haveRead;
}
@end

@implementation PublicNoticeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    haveRead = YES;
    [super creatNavView:@"公告" :NO];
    [self creatSubV];
}

-(void)creatSubV
{
    for (int i = 0; i<2; i++) {
       UIButton  *statusChangeButton = [MethodTool creatButtonWithAttribute:i==0?@"已读":@"未读"
                                                                           :16
                                                                           :i==0?MainNavTextColor:RGB(210, 210, 210, 1)
                                                                           :i==0?[UIColor whiteColor]:RGB(124, 129, 135, 1)];
        statusChangeButton.tag = 100+i;
        [self.sc addSubview:statusChangeButton];
        if (i==0) {
            statusChangeButton.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).widthRatioToView(self.sc,0.5).heightIs(35);
        }
        else{
            statusChangeButton.sd_layout.rightSpaceToView(self.sc,0).topSpaceToView(self.sc,64).widthRatioToView(self.sc,0.5).heightIs(35);
        }
        [statusChangeButton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];

    }
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,10).topSpaceToView(self.sc,115).rightSpaceToView(self.sc,10).bottomSpaceToView(self.sc,10);

    
}


-(void)buttonClick :(UIButton *)sender
{
    for (UIButton *bu in self.sc.subviews) {
        if (bu.tag>99) {
            if ([bu isEqual:sender]) {
                [sender setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [sender setBackgroundColor:MainNavTextColor];
            }
            else{
                [bu setTitleColor:RGB(124, 129, 135, 1) forState:UIControlStateNormal];
                 [bu setBackgroundColor:RGB(210, 210, 210, 1)];

            }
        }
    }
    switch (sender.tag) {
        case 100://已读
            haveRead = YES;
            [Tb reloadData];
            break;
        case 101://未读
            haveRead = NO;
            [Tb reloadData];
            break;
            
        default:
            break;
    }
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70*NEWX;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 15;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    PublicNoticeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[PublicNoticeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.haveRead = haveRead;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-320, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

@end
