//
//  PublicNoticeTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/3/31.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PublicNoticeTableViewCell : UITableViewCell

@property(strong,nonatomic)UILabel *titleLabel;
@property(strong,nonatomic)UILabel *contextLabel;
@property(strong,nonatomic)UILabel *dateLabel;

@property(assign,nonatomic)BOOL haveRead;
@end
