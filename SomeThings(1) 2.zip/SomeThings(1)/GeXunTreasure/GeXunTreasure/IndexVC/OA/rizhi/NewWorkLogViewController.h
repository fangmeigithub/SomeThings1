//
//  NewWorkLogViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewWorkLogViewController : UITableViewController

@end
