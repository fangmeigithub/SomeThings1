//
//  NewWorkLogViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "NewWorkLogViewController.h"
#import "NewWorkLogTableViewCell.h"

@interface NewWorkLogViewController ()
{
    NSArray *leftTextArray ;
}
@end

@implementation NewWorkLogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =  RGB(247, 247, 247, 1);
    [self creatNavView:@"新建工作日志" :NO];
    self.tableView.backgroundColor = [UIColor clearColor];
    leftTextArray  = @[@"已完成的工作:",@"未完成的工作:",@"需协调的工作:"];
   
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    
    for (UIView *subV in self.tableView.subviews) {
        subV.backgroundColor = RGB(247, 247, 247, 1);
    }
}


-(void)creatNavView :(NSString *)text :(BOOL)indexPage
{
    
    UILabel *navLabel = [MethodTool creatLabelWithAttribute:text :18  :2 :MainNavTextColor];
    navLabel.sd_layout.widthIs(80).heightIs(40);
    self.navigationItem.titleView = navLabel;
    if (!indexPage) {
        UIButton *leftB = [[UIButton alloc]init];
        leftB.frame = CGRectMake(0, 20, 45, 50);
        UIImageView *bgImageV = [[UIImageView alloc]init];
        bgImageV.frame = CGRectMake(0, 15, 10, 17);
        bgImageV.image = [UIImage imageNamed:@"back.png"];
        [leftB addSubview:bgImageV];
        leftB.backgroundColor = [UIColor clearColor];
        [leftB addTarget:self action:@selector(cancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
        self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftB];
    }
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 3) {
            return 70;
        }
        else{
            return 40;
        }
    }
    else{
        return 70;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return 10;
    }
    return 0;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 1) {
        return 100;
    }
    return 0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    if (sectionIndex==0) {
        return 4;
    }
    else{
        return 1;
    }
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(247, 247, 247, 1);
    view1.sd_layout.leftSpaceToView(self.tableView,20).topSpaceToView(self.view,10).rightSpaceToView(self.view,10).heightIs(10);
    return view1;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor=[UIColor clearColor];
    view1.sd_layout.leftSpaceToView(self.tableView,20).topSpaceToView(self.tableView,10).rightSpaceToView(self.tableView,10).heightIs(80);
    UIButton *sendButton = [MethodTool creatButtonWithAttribute:@"发送" :15 :MainNavTextColor :[UIColor whiteColor]];
    [view1 addSubview:sendButton];
    sendButton.layer.cornerRadius = 3;
    sendButton.sd_layout.leftSpaceToView(view1,10).topSpaceToView(view1,50).rightSpaceToView(view1,10).heightIs(30);
    
    return view1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    NewWorkLogTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[NewWorkLogTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    
    if ((indexPath.row != 3) && (indexPath.section != 1)) {
        cell.leftLabel.text = [leftTextArray objectAtIndex:indexPath.row];
        //下面的线
        UIView *lineV = [UIView new];
        lineV.backgroundColor = ViewlineColor;
        [cell addSubview:lineV];
        lineV.sd_layout.leftSpaceToView(cell,20).rightSpaceToView(cell,20).topSpaceToView(cell,39.2).heightIs(0.8);

    }
    else{
        if (indexPath.section == 0) {
            [self ViewForCellOne:cell];
        }
        else{
            [self ViewForCellTwo:cell];
        }
    }
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
}

- (void)cancelButtonEvent
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void )ViewForCellOne :(UITableViewCell *)cell
{
    UIView *cellView = [UIView new];
    cellView.backgroundColor = [UIColor whiteColor];
    [cell addSubview:cellView];
    cellView.sd_layout.leftSpaceToView(cell,10).topSpaceToView(cell,0).rightSpaceToView(cell,10).bottomSpaceToView(cell,0);
    
    UILabel *titleLabel = [MethodTool creatLabelWithAttribute:@"备    注:" :14 :1 :blackC];
    [cellView addSubview:titleLabel];
    titleLabel.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,10).widthIs(70);
    
    UIButton *clickB = [MethodTool creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
    [cellView addSubview:clickB];
    [clickB addTarget:self action:@selector(showImage) forControlEvents:UIControlEventTouchUpInside];
    clickB.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,20).widthIs(40).heightIs(40);
    
    UIImageView *imageV = [MethodTool creatImageWithAttribute:@"selectImage.png"];
    [cellView addSubview:imageV];
    imageV.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,30).widthIs(24).heightIs(22);
    

}

-(void )ViewForCellTwo :(UITableViewCell *)cell
{
    UIView *cellView = [UIView new];
    cellView.backgroundColor = [UIColor whiteColor];
    [cell addSubview:cellView];
     cellView.sd_layout.leftSpaceToView(cell,10).topSpaceToView(cell,0).rightSpaceToView(cell,10).bottomSpaceToView(cell,0);
    
    
    UILabel *titleLabel = [MethodTool creatLabelWithAttribute:@"日志接受人：" :14 :1 :blackC];
    [cellView addSubview:titleLabel];
    titleLabel.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,10).widthIs(100);
    
    UIButton *clickB = [MethodTool creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
    [cellView addSubview:clickB];
    [clickB addTarget:self action:@selector(showContactPeople) forControlEvents:UIControlEventTouchUpInside];
    clickB.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,20).widthIs(40).heightIs(40);
    
    UIImageView *imageV = [MethodTool creatImageWithAttribute:@"addContactPeople.png"];
    [cellView addSubview:imageV];
    imageV.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,30).widthIs(24).heightIs(22);
    
}

/**
 *  展示图片
 */
- (void)showImage
{
    
}

//添加收件人
- (void)showContactPeople
{
    
}




@end
