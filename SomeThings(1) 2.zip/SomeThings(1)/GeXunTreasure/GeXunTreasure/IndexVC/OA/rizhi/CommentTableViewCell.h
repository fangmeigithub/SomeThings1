//
//  CommentTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentModel.h"

@interface CommentTableViewCell : UITableViewCell
{
    UIView *bgView;
    UILabel *nameLabel;
    UILabel *timeLabel;
    UILabel *contentLabel;
    UIView *lineV ;
}

@property (nonatomic, strong) CommentModel *model;

@end
