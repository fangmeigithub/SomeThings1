//
//  CommentModel.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel

@end
