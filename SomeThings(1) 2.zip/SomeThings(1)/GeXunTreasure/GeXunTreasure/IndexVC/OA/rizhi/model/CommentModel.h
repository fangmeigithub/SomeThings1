//
//  CommentModel.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentModel : NSObject

@property (nonatomic, copy) NSString *nameStr;
@property (nonatomic, copy) NSString *timeStr;
@property (nonatomic, copy) NSString *contentStr;

@end
