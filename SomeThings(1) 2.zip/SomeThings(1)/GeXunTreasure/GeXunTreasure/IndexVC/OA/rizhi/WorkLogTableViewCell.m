//
//  WorkLogTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "WorkLogTableViewCell.h"

@implementation WorkLogTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(247, 247, 247, 1);
        [self.contentView addSubview:bgView];
        
        NSArray *leftTextArray = @[@"今日完成的工作:",@"未完成的工作:",@"需协调的工作:",@"备注:"];
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,0)
        .topSpaceToView(self.contentView,0)
        .rightSpaceToView(self.contentView,0)
        .bottomSpaceToView(self.contentView,5);
        
        self.nameLabel = [MethodTool creatLabelWithAttribute:@"张小三" :15 :1 :MainNavTextColor];
        [bgView addSubview:self.nameLabel];
        self.nameLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .topSpaceToView(bgView,7)
        .widthIs(50)
        .heightIs(15);
        
        
        self.timeLabel = [MethodTool creatLabelWithAttribute:@"2015.12.33 08:05:26" :14 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.timeLabel];
        self.timeLabel.sd_layout
        .leftSpaceToView(self.nameLabel,10)
        .topEqualToView(self.nameLabel)
        .widthIs(200)
        .heightIs(15);
        
        
        self.numberFujianLabel = [MethodTool creatLabelWithAttribute:@"2" :14 :3 :MainNavTextColor];
        [bgView addSubview:self.numberFujianLabel];
        self.numberFujianLabel.sd_layout
        .rightSpaceToView(bgView,10)
        .topSpaceToView(bgView,10)
        .widthIs(20)
        .heightIs(15);
        
        //别针图片
        UIImageView *imageV = [MethodTool creatImageWithAttribute:@"biezhen.png"];
        [bgView addSubview:imageV];
        imageV.sd_layout.rightSpaceToView(self.numberFujianLabel,0).topSpaceToView(bgView,10).widthIs(13).heightIs(13);
        
        
        //上面的线
        UIView *lineV = [UIView new];
        lineV.backgroundColor = ViewlineColor;
        [bgView addSubview:lineV];
        lineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,33).heightIs(0.8);
        
        
        
        for (int i = 0; i<4; i++) {
            
            UILabel *leftLabel = [MethodTool creatLabelWithAttribute:[leftTextArray objectAtIndex:i] :14 :1 :NEWSTITLECOLOR];
            [bgView addSubview:leftLabel];
            leftLabel.sd_layout
            .leftSpaceToView(bgView,10)
            .topSpaceToView(bgView,40+20*i)
            .widthIs(200)
            .heightIs(15);
        }
        
        //右边的
        
        
    }
    return self;
}


@end
