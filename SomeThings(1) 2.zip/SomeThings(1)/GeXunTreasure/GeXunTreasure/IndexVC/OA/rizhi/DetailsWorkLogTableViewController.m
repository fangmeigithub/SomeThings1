//
//  DetailsWorkLogTableViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "DetailsWorkLogTableViewController.h"
#import "NewWorkLogTableViewCell.h"
#import "CommentTableViewCell.h"
#import "CommentModel.h"
#import "UITableView+SDAutoTableViewCellHeight.h"

@interface DetailsWorkLogTableViewController ()
{
    NSArray *leftTextArray ;
    NSMutableArray *modelArray;
}
@end

@implementation DetailsWorkLogTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =  RGB(247, 247, 247, 1);
    [self creatNavView:@"工作日志详情" :NO];
    self.tableView.backgroundColor = [UIColor clearColor];
    leftTextArray  = @[@"今日完成的工作:",@"未完成的工作:",@"需协调的工作:"];
    modelArray = [[NSMutableArray alloc]initWithCapacity:0];
    
    
    CommentModel *comment1 = [CommentModel new];
    comment1.nameStr = @"张三";
    comment1.timeStr = @"2016-09-09 12:12:21";
    comment1.contentStr = @"iojofjojfofjjfijfjoijfi 佛教界哦jjdojsaoidjoidj哦啊圣诞节jasdjoia就是嗲集散地joadjasdjasdojsajdoasdiasijd啊圣诞节";
    [modelArray addObject:comment1];
    
    CommentModel *comment2 = [CommentModel new];
    comment2.nameStr = @"李四";
    comment2.timeStr = @"2016-09-09 12:12:21";
    comment2.contentStr = @"HAHA";
    [modelArray addObject:comment2];

    CommentModel *comment3 = [CommentModel new];
    comment3.nameStr = @"王五";
    comment3.timeStr = @"2016-09-09 12:12:21";
    comment3.contentStr = @"aasdasdasdasdasdasdadasdwnii你 i 阿";
    [modelArray addObject:comment3];
    
    CommentModel *comment4 = [CommentModel new];
    comment4.nameStr = @"王五s";
    comment4.timeStr = @"2016-09-09 12:12:21";
    comment4.contentStr = @"aasdadasdasdasgggggggggg 啊圣诞节啊圣诞节啊圣诞节阿萨德； 啊圣诞节；阿萨德将阿萨德； 阿萨德 i 阿";
    [modelArray addObject:comment4];
    
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    for (UIView *subV in self.tableView.subviews) {
        subV.backgroundColor = RGB(247, 247, 247, 1);
    }
}


-(void)creatNavView :(NSString *)text :(BOOL)indexPage
{
    
    UILabel *navLabel = [MethodTool creatLabelWithAttribute:text :18  :2 :MainNavTextColor];;
    navLabel.sd_layout.widthIs(80).heightIs(40);
    self.navigationItem.titleView = navLabel;
    if (!indexPage) {
        UIButton *leftB = [[UIButton alloc]init];
        leftB.frame = CGRectMake(0, 20, 45, 50);
        UIImageView *bgImageV = [[UIImageView alloc]init];
        bgImageV.frame = CGRectMake(0, 15, 10, 17);
        bgImageV.image = [UIImage imageNamed:@"back.png"];
        [leftB addSubview:bgImageV];
        leftB.backgroundColor = [UIColor clearColor];
        [leftB addTarget:self action:@selector(cancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
        self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc] initWithCustomView:leftB];
    }
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 50;
    }
    else if (indexPath.section == 1)
    {
        if (indexPath.row == 3) {
            return 70;
        }
        else{
            return 40;
        }
    }
    else{
        CGFloat h = [self cellHeightForIndexPath:indexPath cellContentViewWidth:[UIScreen mainScreen].bounds.size.width];
        return h;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 2) {
        return 50;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    if (sectionIndex==0) {
        return 1;
    }
    else if (sectionIndex == 1){
        return 4;
    }
    else{
        return modelArray.count;
    }
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(247, 247, 247, 1);
    view1.sd_layout.leftSpaceToView(self.tableView,0).topSpaceToView(self.tableView,0).rightSpaceToView(self.tableView,0).heightIs(50);
    
    UIView *headGrayV=[[UIView alloc]init];
    headGrayV.backgroundColor = [UIColor whiteColor];
    [view1 addSubview:headGrayV];
    headGrayV.sd_layout.leftSpaceToView(view1,10).topSpaceToView(view1,10).rightSpaceToView(view1,10).bottomSpaceToView(view1,0);

    UILabel *commentNumebrLabel = [MethodTool creatLabelWithAttribute:[NSString stringWithFormat:@"共有%lu条回复",(unsigned long)modelArray.count] :14 :1 :blackC];
    [headGrayV addSubview:commentNumebrLabel];
    commentNumebrLabel.sd_layout
    .leftSpaceToView(headGrayV,10)
    .topSpaceToView(headGrayV,10)
    .widthIs(110)
    .heightIs(20);
    
    
    UILabel *commentLabel = [MethodTool creatLabelWithAttribute:@"评论" :14 :1 :MainNavTextColor];
    [headGrayV addSubview:commentLabel];
    commentLabel.userInteractionEnabled = YES;
    commentLabel.sd_layout
    .rightSpaceToView(headGrayV,10)
    .topSpaceToView(headGrayV,10)
    .widthIs(30)
    .heightIs(20);
    
    UIImageView *commentImageV = [MethodTool creatImageWithAttribute:@"comment.png"];
    [headGrayV addSubview:commentImageV];
    commentImageV.userInteractionEnabled = YES;
    commentImageV.sd_layout.topEqualToView(commentNumebrLabel).rightSpaceToView(commentLabel,0).widthIs(16).heightIs(16);
    
    UIButton *sendButton = [MethodTool creatButtonWithAttribute:@"" :15 :[UIColor clearColor] :[UIColor whiteColor]];
    [view1 addSubview:sendButton];
    [sendButton addTarget:self action:@selector(editComment) forControlEvents:UIControlEventTouchUpInside];
    sendButton.sd_layout.topEqualToView(commentNumebrLabel).rightSpaceToView(view1,10).widthIs(90).heightIs(40);


    return view1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    NewWorkLogTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[NewWorkLogTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    static NSString *cellIdentifier1 = @"commentCell";
    CommentTableViewCell *cell1 = [tableView dequeueReusableCellWithIdentifier:cellIdentifier1];
    if (!cell1) {
        cell1 = [[CommentTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier1];
        cell1.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    if (indexPath.section == 0){
        
        UIView *v = [cell viewWithTag:1111];
        [v removeFromSuperview];
        [self ViewForCellOne:cell];
        return cell;
    }
    else if (indexPath.section ==1) {
        
        if (indexPath.row == 3) {
            
           [self ViewForCellTwo:cell];
        }
        else{
            
            cell.rightTextFeild.hidden = YES;
            cell.leftLabel.text = [leftTextArray objectAtIndex:indexPath.row];
            //下面的线
            UIView *lineV = [UIView new];
            lineV.backgroundColor = ViewlineColor;
            [cell addSubview:lineV];
            lineV.sd_layout.leftSpaceToView(cell,20).rightSpaceToView(cell,20).topSpaceToView(cell,39.2).heightIs(0.8);
        }
        return cell;
    }//评论区间
    else{
        cell1.model = modelArray[indexPath.row];
        return cell1;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
}

- (void)cancelButtonEvent
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void )ViewForCellOne :(UITableViewCell *)cell{
    
    UIView *cellView = [UIView new];
    cellView.backgroundColor = [UIColor whiteColor];
    [cell addSubview:cellView];
    cellView.sd_layout.leftSpaceToView(cell,10).topSpaceToView(cell,0).rightSpaceToView(cell,10).bottomSpaceToView(cell,0);
    
    UILabel *nameLabel = [MethodTool creatLabelWithAttribute:@"张三" :14 :1 :blackC];
    [cellView addSubview:nameLabel];
    nameLabel.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,10).rightSpaceToView(cellView,10).heightIs(15);
    
    UILabel *timeLabel = [MethodTool creatLabelWithAttribute:@"2016-02-25 12:35:08" :14 :1 :NEWSTITLECOLOR];
    [cellView addSubview:timeLabel];
    timeLabel.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,30).rightSpaceToView(cellView,10).heightIs(15);
    
    //下面的线
    UIView *lineV = [UIView new];
    lineV.backgroundColor = ViewlineColor;
    [cell addSubview:lineV];
    lineV.sd_layout.leftSpaceToView(cell,10).rightSpaceToView(cell,10).topSpaceToView(cell,49.2).heightIs(0.8);
}

-(void )ViewForCellTwo :(UITableViewCell *)cell
{
    UIView *cellView = [UIView new];
    cellView.tag = 1111;
    cellView.backgroundColor = [UIColor whiteColor];
    [cell addSubview:cellView];
    cellView.sd_layout.leftSpaceToView(cell,10).topSpaceToView(cell,0).rightSpaceToView(cell,10).bottomSpaceToView(cell,0);
    
    UILabel *titleLabel = [MethodTool creatLabelWithAttribute:@"备    注:" :14 :1 :blackC];
    [cellView addSubview:titleLabel];
    titleLabel.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,10).widthIs(70);
    
    
    UIImageView *imageV = [MethodTool creatImageWithAttribute:@"defaultImage.png"];
    [cellView addSubview:imageV];
    imageV.sd_layout.leftSpaceToView(cellView,10).topSpaceToView(cellView,30).widthIs(30).heightIs(30);
    
    
}

/**
 *  写评论
 *
 *  @param cell cell
 */
- (void)editComment
{
    
}

@end
