//
//  NewWorkLogTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewWorkLogTableViewCell : UITableViewCell
<UITextFieldDelegate>

@property(strong,nonatomic)UILabel *leftLabel;
@property(strong,nonatomic)UITextField *rightTextFeild;

@end
