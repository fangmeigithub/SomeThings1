//
//  NewWorkLogTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "NewWorkLogTableViewCell.h"

@implementation NewWorkLogTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(247, 247, 247, 1);
        [self.contentView addSubview:bgView];
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,10)
        .topSpaceToView(self.contentView,0)
        .rightSpaceToView(self.contentView,10)
        .bottomSpaceToView(self.contentView,0);
        
        self.leftLabel = [MethodTool creatLabelWithAttribute:@"" :14 :1 :blackC];
        [bgView addSubview:self.leftLabel];
        self.leftLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .topSpaceToView(bgView,10)
        .widthIs(110)
        .heightIs(20);
        
        self.rightTextFeild = [UITextField new];
        self.rightTextFeild.placeholder = @"请输入信息";
        [self.rightTextFeild setValue:[UIFont boldSystemFontOfSize:14] forKeyPath:@"_placeholderLabel.font"];
        [self.rightTextFeild setValue:NEWSCONTEXTCOLOR forKeyPath:@"_placeholderLabel.textColor"];
        self.rightTextFeild.textColor = [UIColor whiteColor];
        self.rightTextFeild.borderStyle = UITextBorderStyleNone;
        self.rightTextFeild.textAlignment = NSTextAlignmentRight;
        self.rightTextFeild.returnKeyType = UIReturnKeyDone;
        self.rightTextFeild.clearButtonMode = UITextFieldViewModeAlways;
        self.rightTextFeild.delegate = self;
        [bgView addSubview:self.rightTextFeild];
        self.rightTextFeild.sd_layout
        .rightSpaceToView(bgView,0)
        .topSpaceToView(bgView,10)
        .widthIs(100)
        .heightIs(20);
        
        
    }
    return self;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
