//
//  WorkLogViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface WorkLogViewController : BaseViewController

@end
