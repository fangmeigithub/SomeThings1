//
//  WorkLogTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/21.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WorkLogTableViewCell : UITableViewCell

@property(strong,nonatomic)UILabel *nameLabel;
@property(strong,nonatomic)UILabel *timeLabel;
@property(strong,nonatomic)UILabel *numberFujianLabel;

@property(strong,nonatomic)UILabel *finishLabel;
@property(strong,nonatomic)UILabel *unFinishLabel;
@property(strong,nonatomic)UILabel *needHelpLabel;
@property(strong,nonatomic)UILabel *remarksLabel;

@end
