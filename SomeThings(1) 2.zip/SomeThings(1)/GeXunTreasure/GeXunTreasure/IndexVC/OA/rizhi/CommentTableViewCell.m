//
//  CommentTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/25.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CommentTableViewCell.h"

@implementation CommentTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(247, 247, 247, 1);
        [self addSubview:bgView];
        
        
        bgView.sd_layout
        .leftSpaceToView(self,10)
        .topSpaceToView(self,0)
        .rightSpaceToView(self,10)
        .bottomSpaceToView(self,0);

        
        nameLabel = [MethodTool creatLabelWithAttribute:@"" :15 :1 :NEWSTITLECOLOR];
        [bgView addSubview:nameLabel];
        nameLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .topSpaceToView(bgView,7)
        .widthIs(80)
        .heightIs(15);
        
        
        timeLabel = [MethodTool creatLabelWithAttribute:@"" :14 :3 :NEWSTITLECOLOR];
        [bgView addSubview:timeLabel];
        timeLabel.sd_layout
        .rightSpaceToView(bgView,10)
        .topEqualToView(nameLabel)
        .widthIs(200)
        .heightIs(15);
        
        
        contentLabel = [MethodTool creatLabelWithAttribute:@"" :14 :1 :NEWSTITLECOLOR];
        [bgView addSubview:contentLabel];
        contentLabel.sd_layout
        .leftSpaceToView(bgView,10)
        .topSpaceToView(bgView,26)
        .rightSpaceToView(bgView, 10)
        .autoHeightRatio(0);
        
        
        //下面的线
        lineV = [UIView new];
        lineV.backgroundColor = ViewlineColor;
        [bgView addSubview:lineV];
        lineV.sd_layout.leftSpaceToView(bgView,10).rightSpaceToView(bgView,10).topSpaceToView(contentLabel,6).heightIs(0.8);
        
        
        
    }
    return self;
}

-(void)setModel:(CommentModel *)model
{
    
    nameLabel.text = model.nameStr;
    timeLabel.text = model.timeStr;
    contentLabel.text = model.contentStr;
    
    [self setupAutoHeightWithBottomView:lineV bottomMargin:10];
}

@end
