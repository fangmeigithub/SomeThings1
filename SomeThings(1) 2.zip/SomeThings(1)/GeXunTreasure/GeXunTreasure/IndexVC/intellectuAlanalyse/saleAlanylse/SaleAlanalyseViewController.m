//
//  SaleAlanalyseViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SaleAlanalyseViewController.h"
#import "GoodsSaleBoardViewController.h"
#import "AreaSaleBoardViewController.h"
#import "CustomerBoardViewController.h"
#import "MonthBoardViewController.h"

@interface SaleAlanalyseViewController ()
{
    NSArray *textArray ;
    
    UIImageView *imageV1;
    UIImageView *imageV2;
    UIImageView *imageV3;
    UIImageView *imageV4;
    
    NSString *className;
}
@end

@implementation SaleAlanalyseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[UIApplication sharedApplication] setApplicationSupportsShakeToEdit:YES];
    [self becomeFirstResponder];
    
    [super creatNavView:@"销售分析" :NO];
    
    textArray  = [[NSArray alloc]initWithObjects:@"月度看板",@"商品看板",@"地区看板",@"客户看板", nil];
    
    [self creatSubV];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = NO;
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    
}

-(void)creatSubV
{
    imageV1 = [MethodTool creatImageWithAttribute:@"sale0"];
    imageV1.alpha = 0;
    imageV1.userInteractionEnabled = YES;
    [self.sc addSubview:imageV1];
    imageV2 = [MethodTool creatImageWithAttribute:@"sale1"];
    imageV2.alpha = 0;
    imageV2.userInteractionEnabled = YES;
    [self.sc addSubview:imageV2];
    imageV3 = [MethodTool creatImageWithAttribute:@"sale2"];
    imageV3.alpha = 0;
    imageV3.userInteractionEnabled = YES;
    [self.sc addSubview:imageV3];
    imageV4 = [MethodTool creatImageWithAttribute:@"sale3"];
    imageV4.alpha = 0;
    imageV4.userInteractionEnabled = YES;
    [self.sc addSubview:imageV4];
    
    
    imageV1.sd_layout.leftSpaceToView(self.sc,50).topSpaceToView(self.sc,120).widthRatioToView(self.sc,0.3).heightEqualToWidth();
    imageV2.sd_layout.topEqualToView(imageV1).rightSpaceToView(self.sc,50).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,60).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV4.sd_layout.topEqualToView(imageV3).rightEqualToView(imageV2).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    
    
    UILabel *label1 = [MethodTool creatLabelWithAttribute:textArray[0] :15 :2 :blackC];
    [self.sc addSubview:label1];
    UILabel *label2 = [MethodTool creatLabelWithAttribute:textArray[1] :15 :2 :blackC];
    [self.sc addSubview:label2];
    UILabel *label3 = [MethodTool creatLabelWithAttribute:textArray[2] :15 :2 :blackC];
    [self.sc addSubview:label3];
    UILabel *label4 = [MethodTool creatLabelWithAttribute:textArray[3] :15 :2 :blackC];
    [self.sc addSubview:label4];
    
    
    label1.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,8).widthRatioToView(imageV1,1).heightIs(30);
    label2.sd_layout.topEqualToView(label1).rightEqualToView(imageV2).widthRatioToView(label1,1).heightRatioToView(label1,1);
    label3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV3,8).widthRatioToView(label1,1).heightRatioToView(label1,1);
    label4.sd_layout.topEqualToView(label3).rightEqualToView(imageV2).widthRatioToView(label1,1).heightRatioToView(label1,1);
    
    
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView1:)];
    UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView2:)];
    UITapGestureRecognizer *tapGe3 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView3:)];
    UITapGestureRecognizer *tapGe4 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView4:)];
    
    [imageV1 addGestureRecognizer:tapGe1];
    [imageV2 addGestureRecognizer:tapGe2];
    [imageV3 addGestureRecognizer:tapGe3];
    [imageV4 addGestureRecognizer:tapGe4];
    
    
    [UIView animateWithDuration:1 animations:^{
        imageV1.alpha = 1;
        imageV2.alpha = 1;
        imageV3.alpha = 1;
        imageV4.alpha = 1;
    }];
    
}


//月度看板
- (void)topAImageView1:(UITapGestureRecognizer *)sender
{
      className = @"MonthBoardViewController";
      [self pushNewVc];
}
//商品看板
- (void)topAImageView2:(UITapGestureRecognizer *)sender
{
       className = @"GoodsSaleBoardViewController";
       [self pushNewVc];
}
//地区看板
- (void)topAImageView3:(UITapGestureRecognizer *)sender
{
        className = @"AreaSaleBoardViewController";
        [self pushNewVc];
}
//客户看板
- (void)topAImageView4:(UITapGestureRecognizer *)sender
{
        className = @"CustomerBoardViewController";
        [self pushNewVc];
}

-(void)pushNewVc
{
    Class cls=NSClassFromString(className);
    id viewController=[[[cls class] alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
}

@end
