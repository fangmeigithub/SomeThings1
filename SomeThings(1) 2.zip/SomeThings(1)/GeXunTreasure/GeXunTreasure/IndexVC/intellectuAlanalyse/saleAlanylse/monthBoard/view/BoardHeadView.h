//
//  BoardHeadView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/17.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BoardGroupModel.h"

@protocol BoardHeadViewDelagate <NSObject>

- (void)boardHeadViewDelagateBack :(NSInteger )celTag;

@end

@interface BoardHeadView : UITableViewHeaderFooterView
{
    UILabel *yearLabel;
    UIImageView *leftImageView ;
}
@property(strong,nonatomic)BoardGroupModel * groupModel;
@property(assign,nonatomic)id  <BoardHeadViewDelagate> myDelegate;

+ (instancetype)initOrderCountGroupWithTableView :(UITableView *)tableView;
@end
