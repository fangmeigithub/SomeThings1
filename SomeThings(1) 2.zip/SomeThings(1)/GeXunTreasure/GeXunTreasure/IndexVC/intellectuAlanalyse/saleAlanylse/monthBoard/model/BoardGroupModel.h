//
//  BoardGroupModel.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/17.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BoardGroupModel : NSObject
@property(strong,nonatomic)NSString *year;
@property(strong,nonatomic)NSArray *monthArray;

@property(assign,nonatomic) BOOL isOpen;

+ (instancetype)initModelWithDic :(NSDictionary *)dataDic;

+ (NSMutableArray *)getDataDic;
@end
