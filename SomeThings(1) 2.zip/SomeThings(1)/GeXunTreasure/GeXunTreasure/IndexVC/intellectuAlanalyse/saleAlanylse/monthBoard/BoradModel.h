//
//  BoradModel.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BoradModel : NSObject

@property(strong,nonatomic)NSString *areaNameStr;
@property(strong,nonatomic)NSString *moneyStr;
@property(strong,nonatomic)NSString *nunberStr;

@end
