//
//  MonthBoardTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/17.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BoardCellModel.h"

@interface MonthBoardTableViewCell : UITableViewCell
{
    UILabel *monthLabel;
    UILabel *numberLabel;
    UILabel *moneyLabel;
    UIImageView *leftImageView;
}
@property(strong,nonatomic)BoardCellModel *cellModel;

+ (instancetype)initOrderCountCellWithTableView :(UITableView *)tableView;
@end
