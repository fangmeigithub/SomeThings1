//
//  BoardHeadView.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/17.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BoardHeadView.h"


@implementation BoardHeadView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        
        /**
         *  深灰色区域
         */
        UIView *grayBgView = [UIView new];
        grayBgView.backgroundColor = RGB(209, 210, 211, 1);
        [self addSubview:grayBgView];
        grayBgView.sd_layout
        .leftSpaceToView(self,0)
        .topSpaceToView(self,0)
        .rightSpaceToView(self,0)
        .heightIs((Scale_Y(40)));
        
        
        yearLabel = [MethodTool creatLabelWithAttribute:@"" :14 :1 :GrayTextColor];
        [grayBgView addSubview:yearLabel];
        yearLabel.sd_layout
        .leftSpaceToView(grayBgView,Scale_X(20))
        .centerYEqualToView(grayBgView)
        .widthIs(Scale_X(100))
        .heightIs(Scale_X(15));
        
        
        leftImageView = [MethodTool creatImageWithAttribute:@"grayjiantou"];
        [grayBgView addSubview:leftImageView];
        leftImageView.sd_layout
        .rightSpaceToView(grayBgView,Scale_X(10))
        .centerYEqualToView(grayBgView)
        .widthIs(Scale_Y(14))
        .heightIs(Scale_Y(14));
        
        
        //细线
        UIView *line = [UIView new];
        line.backgroundColor = RGB(200, 200, 200, 1);
        [grayBgView addSubview:line];
        line.sd_layout
        .leftSpaceToView(grayBgView,0)
        .bottomSpaceToView(grayBgView,0)
        .rightSpaceToView(grayBgView,0)
        .heightIs((Scale_Y(0.5)));
        
        
        UIButton *sectionClickButton = [MethodTool creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
        [grayBgView addSubview:sectionClickButton];
        sectionClickButton.sd_layout
        .spaceToSuperView(UIEdgeInsetsMake(0, 0, 0, 0));
        [sectionClickButton addTarget:self action:@selector(buttonClick :) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return self;
}
+ (instancetype)initOrderCountGroupWithTableView :(UITableView *)tableView;{
    
    static NSString *cellReuseStr = @"cell";
    BoardHeadView *orderCountTBC = [tableView dequeueReusableHeaderFooterViewWithIdentifier:cellReuseStr];
    if (!orderCountTBC) {
        orderCountTBC = [[self alloc]initWithReuseIdentifier:cellReuseStr];
    }
    return orderCountTBC;
}

- (void)setGroupModel:(BoardGroupModel *)groupModel
{
    _groupModel = groupModel;
    yearLabel.text = [MethodTool cleanData:groupModel.year];
    if (!groupModel.isOpen) {
        //没有展开
        [UIView animateWithDuration:0.2 animations:^{
            leftImageView.transform = CGAffineTransformMakeRotation(0);
        }];
    }else {
        //展开
        [UIView animateWithDuration:0.2 animations:^{
            leftImageView.transform = CGAffineTransformMakeRotation(M_PI/2);
        }];
        
    }
}

/**
 *  点击
 */

- (void)buttonClick :(UIButton *)sender
{
    _groupModel.isOpen = !_groupModel.isOpen;
    if (!self.groupModel.isOpen) {
        //没有展开
        [UIView animateWithDuration:0.2 animations:^{
            leftImageView.transform = CGAffineTransformMakeRotation(0);
        }];
    }else {
        //展开
        [UIView animateWithDuration:0.2 animations:^{
            leftImageView.transform = CGAffineTransformMakeRotation(M_PI/2);
        }];
    }
    
    if ([self.myDelegate respondsToSelector:@selector(boardHeadViewDelagateBack:)]) {
        
        [self.myDelegate boardHeadViewDelagateBack:self.tag];
    }
}

@end
