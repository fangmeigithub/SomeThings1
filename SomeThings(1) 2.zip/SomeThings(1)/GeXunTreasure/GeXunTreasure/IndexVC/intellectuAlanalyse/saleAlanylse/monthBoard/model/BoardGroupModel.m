//
//  BoardGroupModel.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/17.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BoardGroupModel.h"
#import "BoardCellModel.h"

@implementation BoardGroupModel
- (instancetype)initModelWithDic :(NSDictionary *)dataDic;
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dataDic];
    }
    return self;
}
+ (instancetype)initModelWithDic :(NSDictionary *)dataDic;
{
    return [[self alloc] initModelWithDic:dataDic];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

+ (NSMutableArray *)getDataDic{
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"order" ofType:@"plist"];
    NSArray *allDataArray = [[NSArray alloc]initWithContentsOfFile:path];
    
    NSMutableArray  *allArray = [[NSMutableArray alloc]initWithCapacity:0];
    NSMutableArray  *mouthAr = [[NSMutableArray alloc]initWithCapacity:0];
    
    for (NSDictionary *yearDic in allDataArray) {
        NSArray *mounthA= yearDic[@"month"];
        for (NSDictionary *dic in mounthA) {
            BoardCellModel *cellModel = [BoardCellModel initModelWithDic:dic];
            [mouthAr addObject:cellModel];
        }
        BoardGroupModel *groupModel = [BoardGroupModel initModelWithDic:yearDic];
        groupModel.monthArray = mouthAr;
        
        [allArray addObject:groupModel];
    }
    
    return allArray;
}
@end
