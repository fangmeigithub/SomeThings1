//
//  CustomerBoardViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CustomerBoardViewController.h"

@interface CustomerBoardViewController ()

@end

@implementation CustomerBoardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initTitle:@"客户订货看板"];
}

- (void)creatModelData
{
    BoradModel *comment1 = [BoradModel new];
    comment1.areaNameStr = @"张三";
    comment1.moneyStr = @"¥ 2000";
    comment1.nunberStr = @"2笔";
    [modelArray addObject:comment1];
    
    BoradModel *comment2 = [BoradModel new];
    comment2.areaNameStr = @"李四";
    comment2.moneyStr = @"¥ 2000";
    comment2.nunberStr = @"2笔";
    [modelArray addObject:comment2];
    
    BoradModel *comment3 = [BoradModel new];
    comment3.areaNameStr = @"王五";
    comment3.moneyStr = @"¥ 2000";
    comment3.nunberStr = @"2笔";
    [modelArray addObject:comment3];
    
}

@end
