//
//  BoardTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BoradModel.h"

@interface BoardTableViewCell : UITableViewCell
{
    UILabel *areaLabel;
    UILabel *moneyLabe;
    UILabel *numberLabel;
    
}

@property (nonatomic, strong) BoradModel *model;

@end
