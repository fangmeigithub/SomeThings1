//
//  AreaSaleBoardViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsSaleBoardViewController.h"

@interface AreaSaleBoardViewController : GoodsSaleBoardViewController

@end
