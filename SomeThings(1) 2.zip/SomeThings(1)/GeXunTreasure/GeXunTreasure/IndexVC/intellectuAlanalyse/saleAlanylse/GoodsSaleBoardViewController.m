//
//  GoodsSaleViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsSaleBoardViewController.h"
#import "BoradModel.h"
#import "BoardTableViewCell.h"

@interface GoodsSaleBoardViewController ()
<UITableViewDataSource,UITableViewDelegate>

@end

@implementation GoodsSaleBoardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initTitle:@"商品销售看板"];
    
    /**
      测试数据
     */
    modelArray = [[NSMutableArray alloc]initWithCapacity:0];
    [self creatModelData];
    
    UIView *whiteBgView = [UIView new];
    whiteBgView.backgroundColor = [UIColor whiteColor];
    [self.sc addSubview:whiteBgView];
    whiteBgView.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).rightSpaceToView(self.sc,0).heightIs(40);
    
    //左边的剪头图标
    UIImageView *ageTimeImageV = [MethodTool creatImageWithAttribute:@"grayjiantou"];
    ageTimeImageV.transform = CGAffineTransformMakeRotation(M_PI);
    ageTimeImageV.userInteractionEnabled = YES;
    [whiteBgView addSubview:ageTimeImageV];
    ageTimeImageV.sd_layout.leftSpaceToView(whiteBgView,20).centerYEqualToView(whiteBgView).widthIs(12).heightIs(12);
    
    
    //右边的剪头图标
    UIImageView *afterTimeImageV = [MethodTool creatImageWithAttribute:@"grayjiantou"];
    [whiteBgView addSubview:afterTimeImageV];
    afterTimeImageV.userInteractionEnabled = YES;
    afterTimeImageV.sd_layout.rightSpaceToView(whiteBgView,20).centerYEqualToView(whiteBgView).widthIs(12).heightIs(12);
    
    
    timeLabel = [MethodTool creatLabelWithAttribute:@"2016-06-01~2016-06-30" :14 :2 :NEWSTITLECOLOR];
    [whiteBgView addSubview:timeLabel];
    timeLabel.sd_layout.centerYEqualToView(whiteBgView).leftSpaceToView(ageTimeImageV,10).rightSpaceToView(afterTimeImageV,10).heightIs(20);
    
    
    //热区
    UIButton *leftClickButton = [MethodTool creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
    [whiteBgView addSubview:leftClickButton];
    [leftClickButton addTarget:self action:@selector(leftClick) forControlEvents:UIControlEventTouchUpInside];
    leftClickButton.sd_layout.leftSpaceToView(whiteBgView,0).topSpaceToView(whiteBgView,0).bottomSpaceToView(whiteBgView,0).widthIs(60);
    
    
    UIButton *rightClickButton = [MethodTool creatButtonWithAttribute:@"" :11 :[UIColor clearColor] :[UIColor clearColor]];
    [whiteBgView addSubview:rightClickButton];
    [rightClickButton addTarget:self action:@selector(rightClick) forControlEvents:UIControlEventTouchUpInside];
    rightClickButton.sd_layout.rightSpaceToView(whiteBgView,0).topSpaceToView(whiteBgView,0).bottomSpaceToView(whiteBgView,0).widthIs(60);

    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=NO;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(whiteBgView,10).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,10);
    
    
}

- (void)initTitle :(NSString *)str
{
     [super creatNavView:str :NO];
}

- (void)creatModelData
{
    BoradModel *comment1 = [BoradModel new];
    comment1.areaNameStr = @"欧莱雅时光";
    comment1.moneyStr = @"¥ 2000";
    comment1.nunberStr = @"2笔";
    [modelArray addObject:comment1];
    
    BoradModel *comment2 = [BoradModel new];
    comment2.areaNameStr = @"京九霄显瘦";
    comment2.moneyStr = @"¥ 2000";
    comment2.nunberStr = @"2笔";
    [modelArray addObject:comment2];
    
    BoradModel *comment3 = [BoradModel new];
    comment3.areaNameStr = @"百雀羚系米南岸";
    comment3.moneyStr = @"¥ 2000";
    comment3.nunberStr = @"2笔";
    [modelArray addObject:comment3];
    
    BoradModel *comment4 = [BoradModel new];
    comment4.areaNameStr = @"屈臣氏哈圣诞节啊";
    comment4.moneyStr = @"¥ 2000";
    comment4.nunberStr = @"2笔";
    [modelArray addObject:comment4];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return modelArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    BoardTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[BoardTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    cell.model = [modelArray objectAtIndex:indexPath.row];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
}

- (void)leftClick
{
    
}
- (void)rightClick
{
    
    
}


@end
