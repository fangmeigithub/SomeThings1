//
//  AreaSaleBoardViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/28.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "AreaSaleBoardViewController.h"
#import "BoradModel.h"


@interface AreaSaleBoardViewController ()

@end

@implementation AreaSaleBoardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super initTitle:@"地区销售看板"];
}

- (void)creatModelData
{
    BoradModel *comment1 = [BoradModel new];
    comment1.areaNameStr = @"北京朝阳区";
    comment1.moneyStr = @"¥ 2000";
    comment1.nunberStr = @"2笔";
    [modelArray addObject:comment1];
    
    BoradModel *comment2 = [BoradModel new];
    comment2.areaNameStr = @"杭州滨江";
    comment2.moneyStr = @"¥ 2000";
    comment2.nunberStr = @"2笔";
    [modelArray addObject:comment2];
    
    BoradModel *comment3 = [BoradModel new];
    comment3.areaNameStr = @"烟台社区";
    comment3.moneyStr = @"¥ 2000";
    comment3.nunberStr = @"2笔";
    [modelArray addObject:comment3];
    
    BoradModel *comment4 = [BoradModel new];
    comment4.areaNameStr = @"齐齐哈尔社区";
    comment4.moneyStr = @"¥ 2000";
    comment4.nunberStr = @"2笔";
    [modelArray addObject:comment4];
}


@end
