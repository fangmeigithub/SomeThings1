//
//  BoardTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BoardTableViewCell.h"

@implementation BoardTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = RGB(247, 247, 247, 1);
        [self addSubview:bgView];
        
        
        bgView.sd_layout
        .leftSpaceToView(self,10)
        .topSpaceToView(self,0)
        .rightSpaceToView(self,10)
        .bottomSpaceToView(self,5);
        
        
        UIImageView *imageV = [MethodTool creatImageWithAttribute:[NSString stringWithFormat:@"board%d",arc4random()%3+1]];
        [bgView addSubview:imageV];
        imageV.sd_layout
        .leftSpaceToView(bgView,10)
        .centerYEqualToView(bgView)
        .widthIs(18)
        .heightIs(18);
        
        
        areaLabel = [MethodTool creatLabelWithAttribute:@"" :14 :1 :NEWSTITLECOLOR];
        [bgView addSubview:areaLabel];
        areaLabel.sd_layout
        .leftSpaceToView(imageV,10)
        .topSpaceToView(bgView,13)
        .rightSpaceToView(bgView,100)
        .heightIs(18);
        
        
        moneyLabe = [MethodTool creatLabelWithAttribute:@"" :13 :3 :REDCOLOR];
        [bgView addSubview:moneyLabe];
        moneyLabe.sd_layout
        .rightSpaceToView(bgView,10)
        .topSpaceToView(bgView,5)
        .widthIs(80)
        .heightIs(15);
        
        
        numberLabel = [MethodTool creatLabelWithAttribute:@"2" :13 :3 :NEWSTITLECOLOR];
        [bgView addSubview:numberLabel];
        numberLabel.sd_layout
        .rightSpaceToView(bgView,10)
        .bottomSpaceToView(bgView,4)
        .widthIs(80)
        .heightIs(15);
        
        
    }
    return self;
}

- (void)setModel:(BoradModel *)model{
    areaLabel.text = model.areaNameStr;
    moneyLabe.text = model.moneyStr;
    numberLabel.text = model.nunberStr;
}

@end
