//
//  GoodsSaleViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "BoradModel.h"

@interface GoodsSaleBoardViewController : BaseViewController
{
    UITableView *Tb;
    UILabel *timeLabel;
    @protected
    NSMutableArray *modelArray;
    
}
@property(strong,nonatomic)NSString *imageName;
- (void)initTitle :(NSString *)str;

@end
