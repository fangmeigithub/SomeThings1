//
//  IntelligentAlanalyseViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "IntelligentAlanalyseViewController.h"
#import "SaleAlanalyseViewController.h"

@interface IntelligentAlanalyseViewController ()
{
    NSArray *textArray ;
    
    UIImageView *imageV1;
    UIImageView *imageV2;
    UIImageView *imageV3;
    UIImageView *imageV4;
    
    NSString *className;
}
@end

@implementation IntelligentAlanalyseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[UIApplication sharedApplication] setApplicationSupportsShakeToEdit:YES];
    [self becomeFirstResponder];
    
    [super creatNavView:@"智能分析" :NO];
    
    textArray  = [[NSArray alloc]initWithObjects:@"销售分析",@"采购分析",@"资金分析",@"人员分析", nil];
    
    [self creatSubV];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = NO;
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    
}

-(void)creatSubV
{
    imageV1 = [MethodTool creatImageWithAttribute:@"Intelligent0"];
    imageV1.alpha = 0;
    imageV1.userInteractionEnabled = YES;
    [self.sc addSubview:imageV1];
    imageV2 = [MethodTool creatImageWithAttribute:@"Intelligent1"];
    imageV2.alpha = 0;
    imageV2.userInteractionEnabled = YES;
    [self.sc addSubview:imageV2];
    imageV3 = [MethodTool creatImageWithAttribute:@"Intelligent2"];
    imageV3.alpha = 0;
    imageV3.userInteractionEnabled = YES;
    [self.sc addSubview:imageV3];
    imageV4 = [MethodTool creatImageWithAttribute:@"Intelligent3"];
    imageV4.alpha = 0;
    imageV4.userInteractionEnabled = YES;
    [self.sc addSubview:imageV4];
    
    
    imageV1.sd_layout.leftSpaceToView(self.sc,Scale_X(40)).topSpaceToView(self.sc,(64+Scale_Y(40))).widthRatioToView(self.sc,0.3).heightEqualToWidth();
    imageV2.sd_layout.topEqualToView(imageV1).rightSpaceToView(self.sc,Scale_Y(40)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,Scale_Y(45)).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    imageV4.sd_layout.topEqualToView(imageV3).rightEqualToView(imageV2).widthRatioToView(imageV1,1).heightRatioToView(imageV1,1);
    
    
    UILabel *label1 = [MethodTool creatLabelWithAttribute:textArray[0] :15 :2 :blackC];
    [self.sc addSubview:label1];
    UILabel *label2 = [MethodTool creatLabelWithAttribute:textArray[1] :15 :2 :blackC];
    [self.sc addSubview:label2];
    UILabel *label3 = [MethodTool creatLabelWithAttribute:textArray[2] :15 :2 :blackC];
    [self.sc addSubview:label3];
    UILabel *label4 = [MethodTool creatLabelWithAttribute:textArray[3] :15 :2 :blackC];
    [self.sc addSubview:label4];
    
    
    label1.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV1,Scale_Y(8)).widthRatioToView(imageV1,1).heightIs(Scale_Y(30));
    label2.sd_layout.topEqualToView(label1).rightEqualToView(imageV2).widthRatioToView(label1,1).heightRatioToView(label1,1);
    label3.sd_layout.leftEqualToView(imageV1).topSpaceToView(imageV3,Scale_Y(8)).widthRatioToView(label1,1).heightRatioToView(label1,1);
    label4.sd_layout.topEqualToView(label3).rightEqualToView(imageV2).widthRatioToView(label1,1).heightRatioToView(label1,1);
    
    
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView1:)];
    UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView2:)];
    UITapGestureRecognizer *tapGe3 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView3:)];
    UITapGestureRecognizer *tapGe4 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView4:)];
    
    [imageV1 addGestureRecognizer:tapGe1];
    [imageV2 addGestureRecognizer:tapGe2];
    [imageV3 addGestureRecognizer:tapGe3];
    [imageV4 addGestureRecognizer:tapGe4];
    
    
    [UIView animateWithDuration:1 animations:^{
        imageV1.alpha = 1;
        imageV2.alpha = 1;
        imageV3.alpha = 1;
        imageV4.alpha = 1;
    }];
    
}


//销售分析
- (void)topAImageView1:(UITapGestureRecognizer *)sender
{
    className = @"SaleAlanalyseViewController";
    [self pushNewVc];
}
//采购分析
- (void)topAImageView2:(UITapGestureRecognizer *)sender
{
    
}
//资金分析
- (void)topAImageView3:(UITapGestureRecognizer *)sender
{
   
}
//人员分析
- (void)topAImageView4:(UITapGestureRecognizer *)sender
{
   
    //    [self.navigationController presentViewController:[[UINavigationController alloc]initWithRootViewController:[[LoginViewController alloc]init]] animated:YES completion:nil];
    
}

-(void)pushNewVc
{
    Class cls=NSClassFromString(className);
    id viewController=[[[cls class] alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
}
@end
