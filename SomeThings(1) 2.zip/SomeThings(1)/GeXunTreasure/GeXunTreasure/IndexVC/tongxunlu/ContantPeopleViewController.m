//
//  ContantPeopleViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "ContantPeopleViewController.h"

@interface ContantPeopleViewController ()

@end

@implementation ContantPeopleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     [super creatNavView:@"通讯录" :NO];
}



@end
