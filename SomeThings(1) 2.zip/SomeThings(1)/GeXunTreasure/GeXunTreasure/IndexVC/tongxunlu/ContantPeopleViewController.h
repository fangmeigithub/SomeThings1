//
//  ContantPeopleViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/4/27.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface ContantPeopleViewController : BaseViewController

@end
