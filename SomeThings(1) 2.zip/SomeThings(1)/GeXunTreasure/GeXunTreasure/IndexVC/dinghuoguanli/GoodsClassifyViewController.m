//
//  GoodsClassifyViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsClassifyViewController.h"
#import "GoodsListViewController.h"

@interface GoodsClassifyViewController ()
<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *Tb;
    
    NSArray *leftArray;
}
@end

@implementation GoodsClassifyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"商品分类" :NO];
    [super  creatRightNavCarButton];
    
    
    leftArray = @[@"鞋子",@"上衣",@"裤子",@"袜子"];
    
    UIButton *allGoods = [MethodTool creatButtonWithAttribute:@"全部商品" :13 :ORANGE_COLOR:[UIColor whiteColor]];
    [self.sc addSubview:allGoods];
    allGoods.layer.cornerRadius = 3;
    [allGoods addTarget:self action:@selector(allGoodsClick) forControlEvents:UIControlEventTouchUpInside];
    allGoods.sd_layout.leftSpaceToView(self.sc,Scale_X(10)).topSpaceToView(self.sc,74).rightSpaceToView(self.sc,Scale_X(10)).heightIs(Scale_Y(35));
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor whiteColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(allGoods,Scale_Y(10)).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,0);
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Scale_X(40);
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return Scale_X(20);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return leftArray.count;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(233, 233, 233, 1);
    view1.sd_layout.leftSpaceToView(Tb,20).topSpaceToView(Tb,10).rightSpaceToView(Tb,10).heightIs(10);
    
    UILabel *allGoodsNumberLabel = [MethodTool creatLabelWithAttribute:@"商品分类" :13 :1 :NEWSTITLECOLOR];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(15)).topSpaceToView(view1,0).rightSpaceToView(view1,100).heightIs(20);
    return view1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *arV = [MethodTool creatImageWithAttribute:@"grayjiantou"];
        arV.bounds = CGRectMake(0, 0, 14, 14);
        cell.accessoryView = arV;
    }
    
    //上面的线
    UIView *headLineV = [UIView new];
    headLineV.backgroundColor = ViewlineColor;
    [cell addSubview:headLineV];
    headLineV.sd_layout.leftSpaceToView(cell,0).rightSpaceToView(cell,0).bottomSpaceToView(cell,0).heightIs(0.8);
    
    cell.textLabel.font = [UIFont systemFontOfSize:13];
    cell.textLabel.textColor = NEWSTITLECOLOR;
    cell.textLabel.text = [leftArray objectAtIndex:indexPath.row];
    
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self.navigationController pushViewController:[[GoodsListViewController alloc]init] animated:YES];
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

//全部商品
- (void)allGoodsClick
{
     [self.navigationController pushViewController:[[GoodsListViewController alloc]init] animated:YES];
}



@end
