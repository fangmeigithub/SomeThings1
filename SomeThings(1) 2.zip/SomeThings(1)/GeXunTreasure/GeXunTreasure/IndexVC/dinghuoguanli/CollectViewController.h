//
//  CollectViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/6.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "RecentBuyViewController.h"

@interface CollectViewController : RecentBuyViewController
{
    UIButton *editButton;
    UIView *bottowView ;
    BOOL cellIsEdit;
}
@end
