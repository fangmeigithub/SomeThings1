//
//  RecentBuyTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "RecentBuyTableViewCell.h"

@implementation RecentBuyTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = RGB(245, 246, 246, 1);
        [self.contentView addSubview:bgView];
        
        
        bgView.sd_layout
        .leftSpaceToView(self.contentView,0)
        .topSpaceToView(self.contentView,0)
        .rightSpaceToView(self.contentView,0)
        .bottomSpaceToView(self.contentView,Scale_Y(5));
        
        
        self.goodsImageView = [MethodTool creatImageWithAttribute:@"effect.png"];
        [bgView addSubview:self.goodsImageView];
        self.goodsImageView.sd_layout
        .leftSpaceToView(bgView,Scale_X(5))
        .topSpaceToView(bgView,Scale_Y(5))
        .bottomSpaceToView(bgView,Scale_Y(5))
        .widthEqualToHeight();
        
        
        
        self.codeLabel = [MethodTool creatLabelWithAttribute:@"编号：009876565" :13 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.codeLabel];
        self.codeLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .topSpaceToView(bgView,Scale_Y(5))
        .widthIs(200)
        .heightIs(15);
        
        
        self.nameLabel = [MethodTool creatLabelWithAttribute:@"阿木正运动透气跑鞋" :13 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.nameLabel];
        self.nameLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .centerYEqualToView(bgView)
        .widthIs(200)
        .heightIs(15);
        
        
        self.contentLabel = [MethodTool creatLabelWithAttribute:@"¥ 1200.00" :13 :1 :ORANGE_COLOR];
        [bgView addSubview:self.contentLabel];
        self.contentLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .bottomSpaceToView(bgView,5)
        .widthIs(100)
        .heightIs(15);
        
        
        //上面的线
        UIView *headLineV = [UIView new];
        headLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:headLineV];
        headLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,0).heightIs(0.8);
        
        //下面的线
        UIView *bottowLineV = [UIView new];
        bottowLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:bottowLineV];
        bottowLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).bottomSpaceToView(bgView,0).heightIs(0.8);
        
        
        //加入购物车
        sendToGoodsCar = [MethodTool creatButtonWithAttribute:@"继续购买" :10 :ORANGE_COLOR :[UIColor whiteColor]];
        [bgView addSubview:sendToGoodsCar];
        sendToGoodsCar.layer.cornerRadius = Scale_X(3);
        [sendToGoodsCar addTarget:self action:@selector(sendToCar) forControlEvents:UIControlEventTouchUpInside];
        sendToGoodsCar.sd_layout.rightSpaceToView(bgView,Scale_X(10)).centerYEqualToView(bgView).widthIs(Scale_X(55)).heightIs(Scale_Y(18));
        
        
        delectButton = [MethodTool creatButtonWithAttribute:@"" :10 :[UIColor clearColor] :[UIColor clearColor]];
        [bgView addSubview:delectButton];
        delectButton.hidden = YES;
        [delectButton setBackgroundImage:[UIImage imageNamed:@"delectBg"] forState:UIControlStateNormal];
        [delectButton addTarget:self action:@selector(delectGoods:) forControlEvents:UIControlEventTouchUpInside];
        delectButton.sd_layout.rightSpaceToView(bgView,Scale_X(10)).centerYEqualToView(bgView).widthIs(Scale_X(30)).heightIs(Scale_X(30));
        

    }
    return self;
}

//加入到购物车
- (void)sendToCar
{
    [self.myDelegate addGoodsToCar:self.tag];
}

- (void)delectGoods :(UIButton *)sender
{
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        [delectButton setBackgroundImage:[UIImage imageNamed:@"delect"] forState:UIControlStateNormal];
        [self.myDelegate selectGoodsForDelect:self.tag];
    }
    else{
        [delectButton setBackgroundImage:[UIImage imageNamed:@"delectBg"] forState:UIControlStateNormal];
        [self.myDelegate cancelSelectGoodsForDelect:self.tag];
    }
}

- (void)setIsEdit:(BOOL)isEdit
{
    
    sendToGoodsCar.hidden = isEdit;
    delectButton.hidden = !isEdit;
}

@end
