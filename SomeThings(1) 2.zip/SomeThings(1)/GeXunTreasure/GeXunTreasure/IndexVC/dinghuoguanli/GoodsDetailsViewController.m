//
//  GoodsDetailsViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/6.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsDetailsViewController.h"
#import "GoodsNumberView.h"
#import "CarViewController.h"

@interface GoodsDetailsViewController ()
{
    UIImageView *shoucangView;
    UILabel *priceLabel;
    
    UIView *bgView;
    NSInteger click;
}
@end

@implementation GoodsDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    [super creatNavView:@"商品详情" :NO];
    [super  creatRightNavCarButton];
    click =0;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    [self initSub];
}
-(void)initSub
{
    UIImageView *bigImageView = [MethodTool creatImageWithAttribute:@"effect1.png"];
    [self.sc addSubview:bigImageView];
    bigImageView.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).rightSpaceToView(self.sc,0).heightIs((143*NEWY));
    
    
    UILabel *codeLabel = [MethodTool creatLabelWithAttribute:@"商品编号：NIke1231312" :12 :1 :blackC];
    [self.sc addSubview:codeLabel];
    codeLabel.sd_layout.leftSpaceToView(self.sc,10).topSpaceToView(bigImageView,(5*NEWY)).widthIs(160).heightIs(15);
    
    UILabel *nameLabel = [MethodTool creatLabelWithAttribute:@"耐克正版运动鞋" :13 :1 :blackC];
    [self.sc addSubview:nameLabel];
    nameLabel.sd_layout.leftEqualToView(codeLabel).topSpaceToView(codeLabel,(5*NEWY)).widthIs(100).heightIs(15);
    
    priceLabel = [MethodTool creatLabelWithAttribute:@"¥ 1200.00" :14 :3 :ORANGE_COLOR];
    [self.sc addSubview:priceLabel];
    priceLabel.sd_layout.rightSpaceToView(self.sc,20).topSpaceToView(bigImageView,(14*NEWY)).widthIs(100).heightIs(15);
    
    //分割线
    UIView *line = [UIView new];
    line.backgroundColor = ViewlineColor;
    [self.sc addSubview:line];
    line.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(nameLabel,(5*NEWY)).rightSpaceToView(self.sc,0).heightIs(0.8);
    
    UIView *eareBgView = [UIView new];
    eareBgView.backgroundColor = RGB(250, 250, 250, 1);
    [self.sc addSubview:eareBgView];
    eareBgView.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(line,0).rightSpaceToView(self.sc,0).heightIs(Scale_Y(6));
    
    GoodsNumberView *goodsV = [[GoodsNumberView alloc]init];
    [self.sc addSubview:goodsV];
    goodsV.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(eareBgView,0).rightSpaceToView(self.sc,0).heightIs(Scale_Y(40) );
    
    
    [self goodsDetailLayoutViewWithDic:nil :goodsV];
    self.sc.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(self.view,0).rightSpaceToView(self.view,0).bottomSpaceToView(self.view,Scale_Y(40));
    [self.sc setContentSize:CGSizeMake(WIDTH, 580*NEWY)];
    
    //底部的收藏和加入购物车
    UIView *lineView = [UIView new];
    lineView.backgroundColor = ViewlineColor;
    [self.view addSubview:lineView];
    lineView.sd_layout.leftSpaceToView(self.view,0).bottomSpaceToView(self.view,(41*NEWY)).widthRatioToView(self.view,0.5).heightIs(0.8);
    
    UIImageView *collectbutton = [MethodTool creatImageWithAttribute:@"jianbian"];
    [self.view addSubview:collectbutton];
    collectbutton.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(collect:)];
    [collectbutton addGestureRecognizer:tapGe1];
    collectbutton.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(lineView,0).bottomSpaceToView(self.view,0).widthRatioToView(self.view,0.5);
    
    UILabel *shoucangLable = [MethodTool creatLabelWithAttribute:@"收藏" :12 :1 :GrayTextColor];
    [collectbutton addSubview:shoucangLable];
    shoucangLable.sd_layout.rightSpaceToView(collectbutton,0).centerYEqualToView(collectbutton).widthRatioToView(collectbutton,0.5).heightIs(15);
    
    shoucangView = [MethodTool creatImageWithAttribute:@"star.png"];
    [collectbutton addSubview:shoucangView];
    shoucangView.sd_layout.rightSpaceToView(shoucangLable,0).centerYEqualToView(collectbutton).widthIs(20).heightIs(20);
    
    
    UIButton *addGoodsCar = [MethodTool creatButtonWithAttribute:@"加入购物车" :12 :ORANGE_COLOR :[UIColor whiteColor]];
    [self.view addSubview:addGoodsCar];
    [addGoodsCar addTarget:self action:@selector(addGoodsCar) forControlEvents:UIControlEventTouchUpInside];
    addGoodsCar.sd_layout.leftSpaceToView(collectbutton,0).topEqualToView(collectbutton).bottomSpaceToView(self.view,0).widthRatioToView(self.view,0.5);
}


//初始化商品详情数据
- (void)goodsDetailLayoutViewWithDic :(NSDictionary *)dataDic :(UIView *)topView
{
    NSArray *leftTextArray = @[@"品牌名称：",
                          @"产品参数：",
                          @"产品名称：",
                          @"颜色分类：",
                          @"款      号：",
                          @"品      牌：",
                          @"性      别：",
                          @"运动鞋科技：",
                          @"功      能：",
                          @"闭合方式："];
    
    
    NSArray *rightArray = @[@"Nike/耐克",
                               @"",
                               @"Nike/耐克/9080 ",
                               @"粉蓝/黑/红色／白色／粉色／蓝色／花色／中色／",
                               @"8097776",
                               @"Nike ",
                               @"女子",
                               @"气垫 透气技术",
                               @"撒打算打算",
                               @"细带"];
    
    bgView = [UIView new];
    [self.sc addSubview:bgView];
    bgView.backgroundColor = [UIColor whiteColor];
    bgView.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(topView,0).rightSpaceToView(self.sc,0).heightIs((240*NEWY));
    
    
    UILabel *titleLabel = [MethodTool creatLabelWithAttribute:@"商品详情" :12 :2 :blackC];
    titleLabel.backgroundColor = RGB(228,229,230,1);
    [bgView addSubview:titleLabel];
    titleLabel.sd_layout.rightSpaceToView(bgView,0).topSpaceToView(bgView,0).rightSpaceToView(bgView,0).heightIs((15*NEWY));
    
    
    for (int i = 0; i<leftTextArray.count; i++) {
        UILabel *leftLabel = [MethodTool creatLabelWithAttribute:[leftTextArray objectAtIndex:i] :13 :1 :GrayTextColor];
        [bgView addSubview:leftLabel];
         leftLabel.sd_layout.leftSpaceToView(bgView,Scale_X(10)).topSpaceToView(bgView,((23+20*i)*NEWY)).widthIs(Scale_X(80)).heightIs(15);
    
        UILabel *rightLable = [MethodTool creatLabelWithAttribute:[rightArray objectAtIndex:i] :13 :1 :GrayTextColor];
        [bgView addSubview:rightLable];
        rightLable.sd_layout.leftSpaceToView(bgView,(i==7?Scale_X(85):Scale_X(75))).topEqualToView(leftLabel).rightSpaceToView(bgView,10).heightIs(15);
    }
    
}
/**
 *  收集
 */
- (void)collect:(UITapGestureRecognizer *)sender
{
    click ++;
    if (click%2==0) {
        shoucangView.image = [UIImage imageNamed:@"star"];
    }
    else{
        shoucangView.image = [UIImage imageNamed:@"redStar"];

    }
}
/**
 *  添加到购物车
 */
- (void)addGoodsCar
{

}



@end
