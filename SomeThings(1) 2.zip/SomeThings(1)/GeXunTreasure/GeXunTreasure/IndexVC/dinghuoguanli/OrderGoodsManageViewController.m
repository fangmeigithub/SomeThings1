//
//  OrderGoodsManageViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderGoodsManageViewController.h"
#import "GoodsTableViewCell.h"
#import "RecentBuyViewController.h"
#import "CollectViewController.h"
#import "GoodsDetailsViewController.h"
#import "OrderView.h"
#import "OrderDetailsViewController.h"
#import "OrderSearchViewController.h"
#import "GoodsClassifyViewController.h" //商品分类
#import "OrderCountViewController.h"

#import "ChoseView.h"


@interface OrderGoodsManageViewController ()
<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIBarPositioningDelegate,orderAffairsDelegate>
{
    UITableView *Tb;
    NSArray *textArray;
    UIView *headBgView;
    
    UISearchBar *mySearchBar;
    UISearchDisplayController *searchDisplayController;
    
    
    
    UIImageView *imageV1; //商品
    UIImageView *imageV2; //订单
    
    OrderView *orderV;
    UIView *lineV;
    
    ChoseView *choseV;
    UIScrollView *scrollV;
    UIView *headBgView1;
}
@end

@implementation OrderGoodsManageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    headBgView1 = [[UIView alloc]initWithFrame:RECT(0, 0, 320, 568, 1)];
    headBgView1.backgroundColor = [UIColor blackColor];
    [self.view addSubview:headBgView1];
    
    scrollV=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, WIDTH,HEIGHT)];
    scrollV.contentSize=CGRectMake(0, 0,320*NEWX,569*NEWY).size;
    scrollV.showsHorizontalScrollIndicator = NO;
    scrollV.showsVerticalScrollIndicator = NO;
    scrollV.backgroundColor = [UIColor whiteColor];
    scrollV.scrollEnabled=YES;
    [headBgView1 addSubview:scrollV];
    
    [super creatNavView:@"订货管理" :NO];
    [super  creatRightNavCarButton];
    
    textArray = @[@"最近订购",@"促销商品",@"收藏商品",@"再次购买"];
    
    [self creatTbHeaderView];
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor whiteColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=NO;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [scrollV addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(scrollV,0).topSpaceToView(headBgView,0).rightSpaceToView(scrollV,0).bottomSpaceToView(scrollV,40);
    
    
    //订单试图
    
    orderV = [OrderView new];
    orderV.frame = self.view.frame;
    orderV.mydelegate = self;
    [orderV creatSubV];
    
    
    UITapGestureRecognizer *tapGe1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView1:)];
    UITapGestureRecognizer *tapGe2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topAImageView2:)];
    //创建底部试图
    

        
    imageV1 = [MethodTool creatImageWithAttribute:@"selectbg"];
    [imageV1 addGestureRecognizer:tapGe1];
    imageV1.userInteractionEnabled = YES;
    [headBgView1 addSubview:imageV1];
    imageV1.sd_layout.leftSpaceToView(headBgView1,0).bottomSpaceToView(headBgView1,0).widthRatioToView(headBgView1,0.5).heightIs((40*NEWY));
    UIImageView *smallImageV = [MethodTool creatImageWithAttribute:@"orderbottow0"];
    [imageV1 addSubview:smallImageV];
    smallImageV.sd_layout.centerXEqualToView(imageV1).centerYEqualToView(imageV1).widthIs((20*NEWX)).heightIs((33*NEWX));

  

    imageV2 = [MethodTool creatImageWithAttribute:@"jianbian"];
    [imageV2 addGestureRecognizer:tapGe2];
    imageV2.userInteractionEnabled = YES;
    [headBgView1 addSubview:imageV2];
    imageV2.sd_layout.leftSpaceToView(headBgView1,(160*NEWX)).bottomSpaceToView(headBgView1,0).widthRatioToView(headBgView1,0.5).heightIs((40*NEWY));
    UIImageView *smallImageV1 = [MethodTool creatImageWithAttribute:@"orderbottow1"];
    [imageV2 addSubview:smallImageV1];
    smallImageV1.sd_layout.centerXEqualToView(imageV2).centerYEqualToView(imageV2).widthIs((20*NEWX)).heightIs((33*NEWX));
    
    
    lineV = [UIView new];
    lineV.backgroundColor = ViewlineColor;
    [headBgView1 addSubview:lineV];
    lineV.sd_layout.leftSpaceToView(headBgView1,0).bottomSpaceToView(imageV1,0).rightSpaceToView(headBgView1,0).heightIs(Scale_Y(0.8));
    
    //添加购物车的试图
    choseV = [ChoseView showInSupView:headBgView1 :scrollV];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    searchDisplayController.active = NO;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65*NEWY;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 3;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(233, 233, 233, 1);
    view1.sd_layout.leftSpaceToView(Tb,20).topSpaceToView(Tb,10).rightSpaceToView(Tb,10).heightIs(10);
    
    UILabel *allGoodsNumberLabel = [MethodTool creatLabelWithAttribute:@"全部商品 3" :13 :1 :ORANGE_COLOR];
    [view1 addSubview:allGoodsNumberLabel];
    allGoodsNumberLabel.attributedText = [self creatAttributedString:[allGoodsNumberLabel text]];
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,5).topSpaceToView(view1,0).rightSpaceToView(view1,100).heightIs(20);
    return view1;

}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    GoodsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[GoodsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    [cell cellClick:^(NSInteger cellIndex) {
        NSLog(@"KKK %ld",(long)cellIndex);
        
        [choseV showOut];
        
    }];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self.navigationController pushViewController:[[GoodsDetailsViewController alloc]init] animated:YES];
}
#pragma UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
//    searchResults = [[NSMutableArray alloc]init];
    
//    if (mySearchBar.text.length>0&&![ChineseInclude isIncludeChineseInString:mySearchBar.text]) {
//        for (int i=0; i<dataArray.count; i++) {
//            if ([ChineseInclude isIncludeChineseInString:dataArray[i]]) {
//                NSString *tempPinYinStr = [PinYinForObjc chineseConvertToPinYin:dataArray[i]];
//                NSRange titleResult=[tempPinYinStr rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
//                if (titleResult.length>0) {
//                    [searchResults addObject:dataArray[i]];
//                }
//            }
//            else {
//                NSRange titleResult=[dataArray[i] rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
//                if (titleResult.length>0) {
//                    [searchResults addObject:dataArray[i]];
//                }
//            }
//        }
//    } else if (mySearchBar.text.length>0&&[ChineseInclude isIncludeChineseInString:mySearchBar.text]) {
//        for (NSString *tempStr in dataArray) {
//            NSRange titleResult=[tempStr rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
//            if (titleResult.length>0) {
//                [searchResults addObject:tempStr];
//            }
//        }
//    }
    
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

/**
 *   顶头的试图
 *
 *  @return 试图
 */

- (void)creatTbHeaderView
{
    headBgView = [UIView new];
    headBgView.backgroundColor = [UIColor whiteColor];
    [scrollV addSubview:headBgView];
    headBgView.frame = RECT(0, 64, 320, 120,0);
    
    
    UIButton *classifiedButton = [MethodTool creatButtonWithAttribute:@"商品分类" :13 :ORANGE_COLOR :[UIColor whiteColor]];
    [headBgView addSubview:classifiedButton];
    classifiedButton.layer.cornerRadius = 3;
    [classifiedButton addTarget:self action:@selector(classified) forControlEvents:UIControlEventTouchUpInside];
    classifiedButton.sd_layout.leftSpaceToView(headBgView,10).topSpaceToView(headBgView,5).widthIs(60).heightIs(25);
    
    mySearchBar = [[UISearchBar alloc] init];
    [headBgView addSubview:mySearchBar];
    mySearchBar.sd_layout.leftSpaceToView(classifiedButton,5).topSpaceToView(headBgView,5).rightSpaceToView(headBgView,5).heightIs(27);
    mySearchBar.placeholder = @"搜索商品名称、编码";
    mySearchBar.delegate =self;
    mySearchBar.layer.cornerRadius=5;
    mySearchBar.layer.masksToBounds=YES;
    [mySearchBar setBackgroundImage:[UIImage imageNamed:@"searchBg"]];
    [mySearchBar setSearchFieldBackgroundImage:[UIImage imageNamed:@"searchBg"] forState:UIControlStateNormal];

    
    //中间的线
    UIView *headLineV = [UIView new];
    headLineV.backgroundColor = ViewlineColor;
    [headBgView addSubview:headLineV];
    headLineV.sd_layout.leftSpaceToView(headBgView,0).topSpaceToView(classifiedButton,7).rightSpaceToView(headBgView,0).heightIs(0.8);
    

    for (int i = 0; i<4; i++) {
        
        UIButton *bgBuuton = [MethodTool creatButtonWithAttribute:@"" :1 :[UIColor clearColor] :[UIColor clearColor]];
        [headBgView addSubview:bgBuuton];
        bgBuuton.frame = RECT(15+80*i, 45, 50, 50,1);
        bgBuuton.tag = 200+i;
        [bgBuuton addTarget:self action:@selector(typeButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *imageViewHead = [MethodTool creatImageWithAttribute:[NSString stringWithFormat:@"orderManage%d.png",i]];
        [headBgView addSubview:imageViewHead];
        imageViewHead.frame = RECT(15+80*i, 45, 50, 50,1);
        
        
        UILabel  *textLabel = [MethodTool creatLabelWithAttribute:[textArray objectAtIndex:i] :13 :2 :NEWSTITLECOLOR];
        [headBgView addSubview:textLabel];
        textLabel.frame = RECT(10+80*i, 100, 60, 15,1);
        
    }
    
}
//创造属性字符（截取部分颜色变化）
-(NSMutableAttributedString *)creatAttributedString :(NSString *)textTitle
{
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:textTitle];
    [str addAttribute:NSForegroundColorAttributeName value:NEWSTITLECOLOR range:NSMakeRange(0, 5)];
    return  str;
}

//商品分类
- (void)classified
{
    [self.navigationController pushViewController:[[GoodsClassifyViewController alloc]init] animated:YES];
}



-(void)typeButtonClick :(UIButton *)sender
{
    switch (sender.tag) {
        case 200: //最近订购
            [self.navigationController pushViewController:[[RecentBuyViewController alloc]init] animated:YES];
            break;
        case 201:
            
            break;
        case 202://收藏夹
            [self.navigationController pushViewController:[[CollectViewController alloc]init] animated:YES];
            break;
        case 203:
            
            break;
            
        default:
            break;
    }
}


//商品
- (void)topAImageView1:(UITapGestureRecognizer *)sender
{
    if (orderV.superview) {
        [orderV removeFromSuperview];
        imageV2.image = [UIImage imageNamed:@"jianbian"];
    }
    if (!scrollV.superview) {
         [headBgView1 addSubview:scrollV];
        imageV1.image = [UIImage imageNamed:@"selectbg"];
    }
    UILabel *navigationItemTitleV = (UILabel *)self.navigationItem.titleView ;
    navigationItemTitleV.text = @"订货管理";
    [headBgView1 bringSubviewToFront:imageV1];
    [headBgView1 bringSubviewToFront:imageV2];
    [headBgView1 bringSubviewToFront:lineV];
    [headBgView1 bringSubviewToFront:choseV];
}
//订单
- (void)topAImageView2:(UITapGestureRecognizer *)sender
{
    if (scrollV.superview) {
        [scrollV removeFromSuperview];
        imageV1.image = [UIImage imageNamed:@"jianbian"];
    }
    if (!orderV.superview) {
        [headBgView1 addSubview:orderV];
        imageV2.image = [UIImage imageNamed:@"selectbg"];
    }
    UILabel *navigationItemTitleV = (UILabel *)self.navigationItem.titleView ;
    navigationItemTitleV.text = @"订单列表";
    [headBgView1 bringSubviewToFront:imageV1];
    [headBgView1 bringSubviewToFront:imageV2];
    [headBgView1 bringSubviewToFront:lineV];
    [headBgView1 bringSubviewToFront:choseV];
    
}




#pragma －－－－－－－－－－－－－－－－－－－orderView delegate－－－－－－－－－－－－－－－－
#pragma <#arguments#>


- (void)cellIndexRowSelect:(NSInteger)cellIndex{
    NSLog(@"第%ld个的订单详情",(long)cellIndex);
    
    [self.navigationController pushViewController:[[OrderDetailsViewController alloc]init] animated:YES];
}

- (void)cellIndexBuyButtonSelect:(NSInteger)cellIndex
{
    NSLog(@"第%ld个订单里的再次购买",(long)cellIndex);
}
//订单查询
- (void)orderSearch
{
    [self.navigationController pushViewController:[[OrderSearchViewController alloc]init] animated:YES];
}
//订单统计
- (void)orderStatistics
{
     [self.navigationController pushViewController:[[OrderCountViewController alloc]init] animated:YES];
}




@end
