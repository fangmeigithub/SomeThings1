//
//  SearchOrderByTimeView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CalendarView.h"
#import "DatePick.h"

@interface SearchOrderByTimeView : UIView
<ActionSheetDIYDelegate>
{
    UILabel *startDateLabel;
    UILabel *endDateLabel;
    
    CalendarView *calendarVOne;
    CalendarView *calendarVTwo;
    
    DatePick *datePickV;
    BOOL starTime;
}

-(void)creatSubV;
@end
