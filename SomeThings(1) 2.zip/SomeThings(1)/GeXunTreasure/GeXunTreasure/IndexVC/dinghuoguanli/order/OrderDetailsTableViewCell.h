//
//  OrderDetailsTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderDetailsTableViewCell : UITableViewCell

@property(strong,nonatomic)UIImageView *goodsImageView;

@property(strong,nonatomic)UILabel *codeLabel;
@property(strong,nonatomic)UILabel *nameLabel;
@property(strong,nonatomic)UILabel *priceLabel;
@property(strong,nonatomic)UILabel *numberLabel; //商品数量

@end
