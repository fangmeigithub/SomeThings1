//
//  OrderView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchOrderByTimeView.h"

@protocol orderAffairsDelegate <NSObject>

@optional
- (void)cellIndexRowSelect :(NSInteger )cellIndex;       //点击某一个cell，查看订单详情
- (void)cellIndexBuyButtonSelect :(NSInteger )cellIndex; //点击某一个cell 上的再次购买
- (void)orderSearch;     //订单查询
- (void)orderStatistics; //订单统计

@end

@interface OrderView : UIView
<UITableViewDataSource,UITableViewDelegate>
{
    UIButton *leftButton,*rightButton;
    UITableView *Tb;
    UIScrollView *sc;
    BOOL haveRead;
    SearchOrderByTimeView *searchOrderByTimeV;
    
}
@property (nonatomic,assign) id <orderAffairsDelegate> mydelegate;

-(void)creatSubV;
@end
