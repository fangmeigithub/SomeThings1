//
//  OrderTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^cellButtonClickBlock)(NSInteger cellIndex);

@interface OrderTableViewCell : UITableViewCell

@property(strong,nonatomic)UIImageView *goodsImageView;

@property(strong,nonatomic)UILabel *codeLabel;    //编号
@property(strong,nonatomic)UILabel *statusLabel;  //状态

@property(strong,nonatomic)UILabel *priceLabel;   //金额
@property(strong,nonatomic)UILabel *numberLabel;  //数量
@property(strong,nonatomic)UILabel *timeLabel;    //下单时间

@property(copy,nonatomic) cellButtonClickBlock cellIndexBlock;

- (void)cellClick :(cellButtonClickBlock)block;
@end
