//
//  ActionPick.h
//  TT
//
//  Created by liubaojian on 15/7/9.
//  Copyright (c) 2015年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ActionSheetDIYDelegate <NSObject>
@optional
-(void)ActionSelectIndex :(NSString *)backStr;
@end

@interface DatePick : UIView
<UIPickerViewDelegate>
{
    UIDatePicker *datePicker;
    UIButton     *bgButton;
}
@property(nonatomic,assign) id <ActionSheetDIYDelegate> delete;

-(void)initViewFrame:(CGRect)viewFrame; //根据数据初始化出pickView里面的数据
-(void)selectAction;  //弹出操作

@end
