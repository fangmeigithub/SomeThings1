//
//  OrderDetailsViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderDetailsViewController.h"
#import "OrderDetailsTableViewCell.h"

@interface OrderDetailsViewController ()
<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *Tb;
    NSArray *sectionArray;
    
    UILabel *statusLabel;
    
    //cellOne
     UILabel *codeLabel;
     UILabel *priceLabel;
     UILabel *timeLabel;
    
    //cellTwo
     UILabel *nameLabel;
     UILabel *phoneLabel;
     UILabel *addressLabel;
    
}
@end

@implementation OrderDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
     [super creatNavView:@"订单详情" :NO];
    
    sectionArray = @[@"订单状态",@"收货信息",@"商品清单"];
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor whiteColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=NO;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,10);
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return sectionArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 2) {
        return 75*NEWY;
    }
    else{
        return 65*NEWY;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    if (sectionIndex == 2) {
        return 2;
    }
    else{
        return 1;
    }
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view1=[[UIView alloc]init];
    view1.backgroundColor = RGB(233, 233, 233, 1);
    view1.sd_layout.leftSpaceToView(Tb,20).topSpaceToView(Tb,10).rightSpaceToView(Tb,10).heightIs(10);
    
    UILabel *allGoodsNumberLabel = [MethodTool creatLabelWithAttribute:[sectionArray objectAtIndex:section] :13 :1 :NEWSTITLECOLOR];
    [view1 addSubview:allGoodsNumberLabel];
    
    allGoodsNumberLabel.sd_layout.leftSpaceToView(view1,Scale_X(5)).topSpaceToView(view1,0).rightSpaceToView(view1,100).heightIs(20);
    
    if (section ==0) {
        statusLabel = [MethodTool creatLabelWithAttribute:@"待收货" :13 :3 :NEWSTITLECOLOR];
        [view1 addSubview:statusLabel];
        statusLabel.sd_layout.rightSpaceToView(view1,Scale_X(10)).centerYEqualToView(view1).widthIs(100).heightIs(15);
    }
    return view1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    static NSString *cellIdentifier1 = @"firstCell1";
    OrderDetailsTableViewCell *cell1 = [tableView dequeueReusableCellWithIdentifier:cellIdentifier1];
    if (!cell1) {
        cell1 = [[OrderDetailsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier1];
        cell1.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    cell.tag = indexPath.row;
    
    if (indexPath.section==0) {
        [self creatCellOne:cell];
        return cell;
    }
    else if (indexPath.section==1){
        [self creatCellTwo:cell];
        return cell;
    }
    else {
        return cell1;
    }
    
    
}

- (void)creatCellOne :(UITableViewCell *)cell
{
    UIView *bgView=[[UIView alloc]init];
    bgView.backgroundColor = [UIColor whiteColor];
    [cell addSubview:bgView];
    bgView.sd_layout.leftSpaceToView(cell,0).topSpaceToView(cell,0).rightSpaceToView(cell,0).bottomSpaceToView(cell,0);
    
    //上面的线
    UIView *headLineV = [UIView new];
    headLineV.backgroundColor = ViewlineColor;
    [bgView addSubview:headLineV];
    headLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,0).heightIs(0.8);
    
    //下面的线
    UIView *bottowLineV = [UIView new];
    bottowLineV.backgroundColor = ViewlineColor;
    [bgView addSubview:bottowLineV];
    bottowLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).bottomSpaceToView(bgView,0).heightIs(0.8);
    
    codeLabel = [MethodTool creatLabelWithAttribute:@"单      号：HN00877788" :13 :1 :NEWSTITLECOLOR];
    [bgView addSubview:codeLabel];
    codeLabel.sd_layout
    .leftSpaceToView(bgView,Scale_X(10))
    .topSpaceToView(bgView,Scale_Y(5))
    .widthIs(Scale_X(300))
    .heightIs(15);
    
    priceLabel = [MethodTool creatLabelWithAttribute:@"订单金额：¥1200.00" :13 :1 :ORANGE_COLOR];
    [bgView addSubview:priceLabel];
    priceLabel.attributedText = [self creatAttributedString:priceLabel.text];
    priceLabel.sd_layout
    .leftSpaceToView(bgView,Scale_X(10))
    .centerYEqualToView(bgView)
    .widthIs(Scale_X(300))
    .heightIs(15);
    
    
    timeLabel = [MethodTool creatLabelWithAttribute:@"下单时间：2016-09-09 12:09:20" :13 :1 :NEWSTITLECOLOR];
    [bgView addSubview:timeLabel];
    timeLabel.sd_layout
    .leftSpaceToView(bgView,Scale_X(10))
    .bottomSpaceToView(bgView,Scale_Y(5))
    .widthIs(Scale_X(300))
    .heightIs(15);
    

    
    UIButton *sendToGoodsCar = [MethodTool creatButtonWithAttribute:@"确认收货" :10 :ORANGE_COLOR :[UIColor whiteColor]];
    [bgView addSubview:sendToGoodsCar];
    sendToGoodsCar.layer.cornerRadius = 3;
    [sendToGoodsCar addTarget:self action:@selector(buttonclick) forControlEvents:UIControlEventTouchUpInside];
    sendToGoodsCar.sd_layout.rightSpaceToView(bgView,10).centerYEqualToView(bgView).widthIs(55).heightIs(18);
    
    
}

- (void)creatCellTwo :(UITableViewCell *)cell
{
    UIView *bgView=[[UIView alloc]init];
    bgView.backgroundColor = [UIColor whiteColor];
    [cell addSubview:bgView];
    bgView.sd_layout.leftSpaceToView(cell,0).topSpaceToView(cell,0).rightSpaceToView(cell,0).bottomSpaceToView(cell,0);
    
    //上面的线
    UIView *headLineV = [UIView new];
    headLineV.backgroundColor = ViewlineColor;
    [bgView addSubview:headLineV];
    headLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,0).heightIs(0.8);
    
    //下面的线
    UIView *bottowLineV = [UIView new];
    bottowLineV.backgroundColor = ViewlineColor;
    [bgView addSubview:bottowLineV];
    bottowLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).bottomSpaceToView(bgView,0).heightIs(0.8);
    

    nameLabel = [MethodTool creatLabelWithAttribute:@"收货人：张三" :13 :1 :NEWSTITLECOLOR];
    [bgView addSubview:nameLabel];
    nameLabel.sd_layout
    .leftSpaceToView(bgView,Scale_X(10))
    .topSpaceToView(bgView,Scale_Y(5))
    .widthIs(Scale_X(300))
    .heightIs(15);
    
    
    phoneLabel = [MethodTool creatLabelWithAttribute:@"联系电话：15098765678" :13 :1 :NEWSTITLECOLOR];
    [bgView addSubview:phoneLabel];
    phoneLabel.sd_layout
    .leftSpaceToView(bgView,Scale_X(10))
    .centerYEqualToView(bgView)
    .widthIs(Scale_X(300))
    .heightIs(15);
    
    
    addressLabel = [MethodTool creatLabelWithAttribute:@"收货地址：杭州滨江区华业大厦22222222" :13 :1 :NEWSTITLECOLOR];
    [bgView addSubview:addressLabel];
    addressLabel.sd_layout
    .leftSpaceToView(bgView,Scale_X(10))
    .bottomSpaceToView(bgView,Scale_Y(5))
    .widthIs(Scale_X(300))
    .heightIs(15);
}

- (void)buttonclick
{
    
}

//创造属性字符（截取部分颜色变化）
-(NSMutableAttributedString *)creatAttributedString :(NSString *)textTitle
{
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:textTitle];
    [str addAttribute:NSForegroundColorAttributeName value:NEWSTITLECOLOR range:NSMakeRange(0, 5)];
    return  str;
}

@end
