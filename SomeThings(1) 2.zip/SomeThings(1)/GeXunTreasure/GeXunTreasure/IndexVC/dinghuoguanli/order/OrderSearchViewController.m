//
//  OrderSearchViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderSearchViewController.h"

#import "SearchOrderByTimeView.h"
@interface OrderSearchViewController ()

@end

@implementation OrderSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"订单查询" :NO];
    
    SearchOrderByTimeView  *searchOrderByTimeV = [[SearchOrderByTimeView alloc]initWithFrame:RECT(0,64, 320, HEIGHT-64, 0)];
    [searchOrderByTimeV creatSubV];
    [self.sc addSubview:searchOrderByTimeV];
}

@end
