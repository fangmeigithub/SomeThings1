//
//  OrderView.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderView.h"
#import "OrderTableViewCell.h"



@implementation OrderView


-(void)creatSubV
{
    
    sc=[[UIScrollView alloc]init];
    sc.contentSize=CGRectMake(0, 0,self.frame.size.width,self.frame.size.height+1).size;
    sc.showsHorizontalScrollIndicator = NO;
    sc.showsVerticalScrollIndicator = NO;
    sc.backgroundColor = [UIColor whiteColor];
    sc.scrollEnabled=YES;
    [self addSubview:sc];
    sc.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).bottomSpaceToView(self,0);
    
    for (int i = 0; i<2; i++) {
        
        
        
        
        UIButton  *statusChangeButton = [MethodTool creatButtonWithAttribute:i==0?@"订单查询":@"订单统计"
                                                                            :15
                                                                            :[UIColor whiteColor]
                                                                            :RGB(124, 129, 135, 1)];
        statusChangeButton.tag = 100+i;
        [sc addSubview:statusChangeButton];
        
        UIImageView *actionImageV = [MethodTool creatImageWithAttribute:(i==0?@"order0":@"order1")];
        [sc addSubview:actionImageV];

        if (i==0) {
            statusChangeButton.sd_layout.leftSpaceToView(sc,0).topSpaceToView(sc,66).widthRatioToView(sc,0.5).heightIs(Scale_Y(30));
            actionImageV.sd_layout
            .leftSpaceToView(sc,Scale_X(25))
            .topSpaceToView(sc,(66+Scale_Y(4)))
            .widthIs(Scale_Y(22))
            .heightIs(Scale_Y(22));
        }
        else{
            statusChangeButton.sd_layout.rightSpaceToView(sc,0).topSpaceToView(sc,66).widthRatioToView(sc,0.5).heightIs(Scale_Y(35));
            actionImageV.sd_layout
            .rightSpaceToView(sc,Scale_X(113))
            .topSpaceToView(sc,(66+Scale_Y(4)))
            .widthIs(Scale_Y(22))
            .heightIs(Scale_Y(22));
        }
        [statusChangeButton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    //竖线
    UIView *lineV  = [UIView new];
    [sc addSubview:lineV];
    lineV.backgroundColor = ViewlineColor;
    lineV.sd_layout.topSpaceToView(sc,66).centerXEqualToView(sc).widthIs(0.8).heightIs(Scale_Y(30));
    
    Tb = [[UITableView alloc] initWithFrame:RECT(0, (Scale_Y(35)+65), 320, HEIGHT-64, 0) style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [sc addSubview:Tb];
    
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 85*NEWY;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 3;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    OrderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[OrderTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    [cell cellClick:^(NSInteger cellIndex) {
        [self.mydelegate cellIndexBuyButtonSelect:cellIndex];
    }];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self.mydelegate cellIndexRowSelect:indexPath.row];
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-(320*NEWX), cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}


-(void)buttonClick :(UIButton *)sender
{
    switch (sender.tag) {
        case 100://订单查询
            [self.mydelegate orderSearch];
            break;
        case 101://订单列表
            [self.mydelegate orderStatistics];
            break;
            
        default:
            break;
    }
    
    
}


@end
