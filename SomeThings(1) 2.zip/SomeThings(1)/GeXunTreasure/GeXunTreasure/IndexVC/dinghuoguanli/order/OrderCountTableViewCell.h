//
//  OrderCountTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderCountCellModel.h"

@interface OrderCountTableViewCell : UITableViewCell
{
    UILabel *monthLabel;
    UILabel *numberLabel;
    UILabel *moneyLabel;
    UIImageView *leftImageView;
}
@property(strong,nonatomic)OrderCountCellModel *cellModel;

+ (instancetype)initOrderCountCellWithTableView :(UITableView *)tableView;
@end
