//
//  OrderCountHeadView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderCountGroupModel.h"


@protocol OrderCountHeadViewDelagate <NSObject>

- (void)OrderCountHeadViewDelagateBack :(NSInteger )celTag;

@end

@interface OrderCountHeadView : UITableViewHeaderFooterView
{
    UILabel *yearLabel;
    UIImageView *leftImageView ;
}
@property(strong,nonatomic)OrderCountGroupModel * groupModel;
@property(assign,nonatomic)id  <OrderCountHeadViewDelagate> myDelegate;

+ (instancetype)initOrderCountGroupWithTableView :(UITableView *)tableView;
@end
