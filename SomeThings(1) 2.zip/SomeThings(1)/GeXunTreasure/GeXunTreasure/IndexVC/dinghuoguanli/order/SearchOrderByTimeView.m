//
//  SearchOrderByTimeView.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "SearchOrderByTimeView.h"


@implementation SearchOrderByTimeView

-(void)creatSubV
{
    self.backgroundColor = RGB(245, 246, 246, 1);
    
    for (int i = 0; i<2; i++) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        [self addSubview:bgView];
        bgView.sd_layout
        .leftSpaceToView(self,Scale_X(20))
        .topSpaceToView(self,((Scale_Y(40)+10)*i+Scale_Y(20)))
        .rightSpaceToView(self,Scale_X(20))
        .heightIs(Scale_Y(40));
        
        UILabel *label = [MethodTool creatLabelWithAttribute:(i==0?@"开始日期":@"结束日期") :14 :1 :NEWSTITLECOLOR];
        [bgView addSubview:label];
        label.sd_layout
        .leftSpaceToView(bgView,Scale_X(10))
        .centerYEqualToView(bgView)
        .widthIs(Scale_X(100))
        .heightIs(15);
        
        
        UILabel *dateLable = [MethodTool creatLabelWithAttribute:@"2016-04-27" :14 :2 :GrayTextColor];
        [bgView addSubview:dateLable];
        dateLable.sd_layout
        .centerXEqualToView(bgView)
        .centerYEqualToView(bgView)
        .widthIs(Scale_X(100))
        .heightIs(15);
    
        
        CalendarView *calendarV = [CalendarView new];
        [bgView addSubview:calendarV];
        calendarV.sd_layout.rightSpaceToView(bgView,Scale_X(5)).centerYEqualToView(bgView).heightIs(Scale_Y(22)).widthIs(Scale_X(22));
        [calendarV initSubV];
        
        UIButton *selecTimetButton = [MethodTool creatButtonWithAttribute:@"" :14 :[UIColor clearColor] :[UIColor clearColor]];
        [bgView addSubview:selecTimetButton];
        selecTimetButton.tag = 500+i;
        [selecTimetButton addTarget:self action:@selector(selectTime:) forControlEvents:UIControlEventTouchUpInside];
        selecTimetButton.sd_layout.rightSpaceToView(bgView,0).topSpaceToView(bgView,0).bottomSpaceToView(bgView,0).widthIs(Scale_X(50));
        
        if (i==0) {
            startDateLabel = dateLable;
            calendarVOne = calendarV ;
        }
        else{
            endDateLabel = dateLable;
            calendarVTwo  =  calendarV;
        }
        
    }

    
    UIButton *sendToGoodsCar = [MethodTool creatButtonWithAttribute:@"查询" :14 :MainNavTextColor :[UIColor whiteColor]];
    [self addSubview:sendToGoodsCar];
    sendToGoodsCar.layer.cornerRadius = 3;
    [sendToGoodsCar addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];
    sendToGoodsCar.sd_layout.leftSpaceToView(self,Scale_X(10)).rightSpaceToView(self,Scale_X(10)).topSpaceToView(self,Scale_Y(130)).heightIs(Scale_Y(35));
    
    
    datePickV = [[DatePick alloc]init];
    datePickV.delete = self;
    [datePickV initViewFrame:RECT(0, 568, 320, 568, 0)];
   
}
- (void)selectTime :(UIButton *)sender
{
    switch (sender.tag) {
        case 500: //选择起始时间
            starTime = YES;
            break;
        case 501://选择终止时间
            starTime = NO;
            break;
        default:
            break;
            
    }
    [self addSubview:datePickV];
    [datePickV setFrame:RECT(0, 0, 320, 568, 0)];
    [datePickV selectAction];
}

- (void)search
{
    
}

#pragma datePickDelegate++++++++++++++++++++++++

//设置时间和日历上的显示时间
- (void)ActionSelectIndex:(NSString *)backStr
{
    if (starTime) {
        startDateLabel.text = backStr;
        [calendarVOne setDateView:backStr];
    }else{
        endDateLabel.text = backStr;
        [calendarVTwo setDateView:backStr];
    }
    
}

@end
