//
//  OrderCountViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//
/**
 *  订单统计
 */



#import "OrderCountViewController.h"
#import "OrderCountGroupModel.h"
#import "OrderCountHeadView.h"
#import "OrderCountTableViewCell.h"

@interface OrderCountViewController ()
<UITableViewDelegate,UITableViewDataSource,OrderCountHeadViewDelagate>
{
    UITableView *Tb;
    NSArray *dataArray;
}
@end

@implementation OrderCountViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"订单统计" :NO];
    
    dataArray = [NSArray arrayWithArray:[OrderCountGroupModel getDataDic]] ;
    
    self.sc.scrollEnabled = NO;
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor clearColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,74).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,Scale_Y(10));

}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return dataArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Scale_Y(45);
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return Scale_Y(40);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    OrderCountGroupModel *cellGroup  = [dataArray objectAtIndex:sectionIndex];
    return cellGroup.isOpen?cellGroup.monthArray.count:0;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    OrderCountHeadView *viewHeadV = [OrderCountHeadView initOrderCountGroupWithTableView:tableView];
    viewHeadV.groupModel = [dataArray objectAtIndex:section];
    viewHeadV.tag = section;
    viewHeadV.myDelegate = self;
    return viewHeadV;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    OrderCountTableViewCell *cell = [OrderCountTableViewCell initOrderCountCellWithTableView:tableView];
    OrderCountGroupModel *cellGroup  = [dataArray objectAtIndex:indexPath.section];
    cell.tag = indexPath.row;
    cell.cellModel = [cellGroup.monthArray objectAtIndex:indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
}

- (void)OrderCountHeadViewDelagateBack:(NSInteger)celTag
{
    NSIndexSet *set = [[NSIndexSet alloc]initWithIndex:celTag];
    [Tb reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
}

@end
