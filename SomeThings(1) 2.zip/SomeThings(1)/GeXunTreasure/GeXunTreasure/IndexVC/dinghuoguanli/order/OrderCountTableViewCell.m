//
//  OrderCountTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderCountTableViewCell.h"
#import "NSString+CodeAndClean.h"

@implementation OrderCountTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        /**
         *  深灰色区域
         */
        UIView *grayBgView = [UIView new];
        grayBgView.backgroundColor = RGB(245, 245, 245, 1);
        [self addSubview:grayBgView];
        grayBgView.sd_layout
        .leftSpaceToView(self,0)
        .topSpaceToView(self,0)
        .rightSpaceToView(self,0)
        .heightIs((Scale_Y(45)));
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        /**
         *  白色区域
         */
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = [UIColor whiteColor];
        [grayBgView addSubview:bgView];
        [bgView.layer setBorderWidth:0.8];
        [bgView.layer setBorderColor:ViewlineColor.CGColor];
        bgView.sd_layout
        .leftSpaceToView(grayBgView,Scale_X(20))
        .topSpaceToView(grayBgView,Scale_Y(4))
        .rightSpaceToView(grayBgView,Scale_X(5))
        .bottomSpaceToView(grayBgView,Scale_Y(4));
        
        
        leftImageView = [MethodTool creatImageWithAttribute:[NSString stringWithFormat:@"%dy",(self.tag%2)]];
        [grayBgView addSubview:leftImageView];
        leftImageView.sd_layout
        .leftSpaceToView(grayBgView,Scale_X(7))
        .topSpaceToView(grayBgView,Scale_Y(2))
        
        .widthIs(Scale_Y(41))
        .heightIs(Scale_Y(41));
        
        
        monthLabel = [MethodTool creatLabelWithAttribute:@"" :14 :2 :[UIColor whiteColor]];
        [grayBgView addSubview:monthLabel];
        monthLabel.sd_layout
        .centerXEqualToView(leftImageView)
        .centerYEqualToView(leftImageView)
        .widthRatioToView(leftImageView,1)
        .heightIs(Scale_Y(15));
        
        
        numberLabel = [MethodTool creatLabelWithAttribute:@"" :13 :1 :NEWSTITLECOLOR];
        [grayBgView addSubview:numberLabel];
        numberLabel.sd_layout
        .leftSpaceToView(grayBgView,Scale_X(95))
        .centerYEqualToView(grayBgView)
        .widthIs(Scale_X(100))
        .heightIs(Scale_X(15));
        
        
        moneyLabel = [MethodTool creatLabelWithAttribute:@"" :13 :3 :ORANGE_COLOR];
        [grayBgView addSubview:moneyLabel];
        moneyLabel.sd_layout
        .rightSpaceToView(grayBgView,(20*NEWX))
        .centerYEqualToView(grayBgView)
        .widthIs(Scale_X(100))
        .heightIs(Scale_Y(15));

    }
    return self;
}
+ (instancetype)initOrderCountCellWithTableView :(UITableView *)tableView;{
    static NSString *cellReuseStr = @"cell";
    OrderCountTableViewCell *orderCountTBC = [tableView dequeueReusableCellWithIdentifier:cellReuseStr];
    if (!orderCountTBC) {
        orderCountTBC = [[self alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellReuseStr];
    }
    return orderCountTBC;
}

- (void)setCellModel :(OrderCountCellModel *)cellModel
{
    monthLabel.text =  [MethodTool cleanData:cellModel.mounth];
    numberLabel.text = [[MethodTool cleanData:cellModel.number]stringWithFormMat:@"订货%@笔"];
    moneyLabel.text = [[MethodTool cleanData:cellModel.money] stringWithFormMat:@"¥ %@"];
    leftImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%dy",(self.tag%2)]];
}


@end
