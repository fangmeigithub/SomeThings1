//
//  ActionPick.m
//  TT
//
//  Created by liubaojian on 15/7/9.
//  Copyright (c) 2015年 liubaojian. All rights 。reserved.
//

#import "DatePick.h"

@implementation DatePick

-(void)initViewFrame:(CGRect)viewFrame;
{
    self.frame = viewFrame;
    self.backgroundColor = [UIColor clearColor];
    
    bgButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [bgButton addTarget:self action:@selector(hideAction) forControlEvents:UIControlEventTouchUpInside];
    bgButton.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    
    datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, self.frame.size.height, self.frame.size.width, Scale_Y(100))];
    datePicker.backgroundColor =[UIColor whiteColor];
    datePicker.datePickerMode = UIDatePickerModeDate;
   
}
-(void)selectAction
{
    [self addSubview:bgButton];
    [self addSubview:datePicker];
    NSTimeInterval animationDuration =0.3;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    datePicker.frame = CGRectMake(0, self.frame.size.height-Scale_Y(260), self.frame.size.width, Scale_Y(200));
    [UIView commitAnimations];
}
-(void)hideAction
{
    
    NSDateFormatter *formatter =[[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *timestamp = [formatter stringFromDate:datePicker.date];
    [self.delete  ActionSelectIndex:timestamp];
    NSTimeInterval animationDuration =0.6;
    [UIView beginAnimations:nil context:nil];
    [UIView animateWithDuration:animationDuration animations:^
     {
         datePicker.frame = CGRectMake(0, self.frame.size.height+200*NEWY, self.frame.size.width, Scale_Y(200));
     }
                     completion:^(BOOL finished)
     {
         [bgButton removeFromSuperview];
         [datePicker removeFromSuperview];
         [self removeFromSuperview];
     }];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    [UIView commitAnimations];
    

}


@end
