//
//  OrderTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderTableViewCell.h"

@implementation OrderTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        /**
         *  深灰色区域
         */
        UIView *grayBgView = [UIView new];
        grayBgView.backgroundColor = RGB(228, 229, 230, 1);
        [self addSubview:grayBgView];
        grayBgView.sd_layout
        .leftSpaceToView(self,0)
        .topSpaceToView(self,0)
        .rightSpaceToView(self,0)
        .heightIs((Scale_Y(16)));
        
        self.codeLabel = [MethodTool creatLabelWithAttribute:@"DF00233444" :13 :1 :NEWSTITLECOLOR];
        [grayBgView addSubview:self.codeLabel];
        self.codeLabel.sd_layout
        .leftSpaceToView(grayBgView,(5*NEWX))
        .centerYEqualToView(grayBgView)
        .widthIs(Scale_X(200))
        .heightIs(15);
        
        
        self.statusLabel = [MethodTool creatLabelWithAttribute:@"待审核" :12 :3 :NEWSTITLECOLOR];
        [grayBgView addSubview:self.statusLabel];
        self.statusLabel.sd_layout
        .rightSpaceToView(grayBgView,(10*NEWX))
        .centerYEqualToView(grayBgView)
        .widthIs(200)
        .heightIs(15);

        
        /**
         *  浅灰色区域
         */
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = RGB(245, 246, 246, 1);
        [self addSubview:bgView];
        bgView.sd_layout
        .leftSpaceToView(self,0)
        .topSpaceToView(grayBgView,0)
        .rightSpaceToView(self,0)
        .bottomSpaceToView(self,Scale_Y(3));
        
        
        self.goodsImageView = [MethodTool creatImageWithAttribute:@"effect.png"];
        [bgView addSubview:self.goodsImageView];
        self.goodsImageView.sd_layout
        .leftSpaceToView(bgView,Scale_X(5))
        .topSpaceToView(bgView,Scale_Y(5))
        .bottomSpaceToView(bgView,Scale_Y(5))
        .widthEqualToHeight();
        
        
        
        self.priceLabel = [MethodTool creatLabelWithAttribute:@"订单金额：¥ 1200.00" :13 :1 :ORANGE_COLOR];
        [bgView addSubview:self.priceLabel];
        self.priceLabel.attributedText = [self creatAttributedString:self.priceLabel.text];
        self.priceLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .topSpaceToView(bgView,Scale_Y(5))
        .widthIs(200)
        .heightIs(15);
        
        
        self.numberLabel = [MethodTool creatLabelWithAttribute:@"商品数量：1" :13 :1 :ORANGE_COLOR];
        [bgView addSubview:self.numberLabel];
        self.numberLabel.attributedText = [self creatAttributedString:self.numberLabel.text];
        self.numberLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .centerYEqualToView(bgView)
        .widthIs(200)
        .heightIs(15);
        
        
        self.timeLabel = [MethodTool creatLabelWithAttribute:@"下单时间：2016-08-09 15:19:08" :13 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.timeLabel];
        self.timeLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .bottomSpaceToView(bgView,Scale_Y(5))
        .widthIs(200)
        .heightIs(15);
        
        
        //上面的线
        UIView *headLineV = [UIView new];
        headLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:headLineV];
        headLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,0).heightIs(0.8);
        
        //下面的线
        UIView *bottowLineV = [UIView new];
        bottowLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:bottowLineV];
        bottowLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).bottomSpaceToView(bgView,0).heightIs(0.8);
        
        
        //加入购物车
        UIButton *sendToGoodsCar = [MethodTool creatButtonWithAttribute:@"再次购买" :10 :ORANGE_COLOR :[UIColor whiteColor]];
        [bgView addSubview:sendToGoodsCar];
        sendToGoodsCar.layer.cornerRadius = 3;
        [sendToGoodsCar addTarget:self action:@selector(sendToCar) forControlEvents:UIControlEventTouchUpInside];
        sendToGoodsCar.sd_layout.rightSpaceToView(bgView,Scale_X(10)).centerYEqualToView(bgView).widthIs(Scale_X(55)).heightIs(Scale_Y(18));
        
        
    }
    return self;
}

//创造属性字符（截取部分颜色变化）
-(NSMutableAttributedString *)creatAttributedString :(NSString *)textTitle
{
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:textTitle];
    [str addAttribute:NSForegroundColorAttributeName value:NEWSTITLECOLOR range:NSMakeRange(0, 5)];
    return  str;
}
-(void)sendToCar
{
    self.cellIndexBlock(self.tag);
}
- (void)cellClick :(cellButtonClickBlock)block;{
    self.cellIndexBlock = block;
}
@end
