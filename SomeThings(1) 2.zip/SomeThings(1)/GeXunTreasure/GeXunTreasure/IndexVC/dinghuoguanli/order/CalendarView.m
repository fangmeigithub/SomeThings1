//
//  CalendarView.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CalendarView.h"
#import "MethodTool.h"

@implementation CalendarView


- (void)initSubV;
{
    UIImageView *bgImageV = [MethodTool creatImageWithAttribute:@"rili"];
    [self addSubview: bgImageV];
    bgImageV.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).bottomSpaceToView(self,0);
    
    mouthLabel = [MethodTool creatLabelWithAttribute:@"06" :8 :1 :[UIColor whiteColor]];
    [self addSubview:mouthLabel];
    mouthLabel.sd_layout
    .leftSpaceToView(self,0)
    .topSpaceToView(self,Scale_Y(5))
    .rightSpaceToView(self,0)
    .heightIs(6);
    
    dayLabel = [MethodTool creatLabelWithAttribute:@"27" :14 :2 :[UIColor blackColor]];
    [self addSubview:dayLabel];
    dayLabel.sd_layout
    .leftSpaceToView(self,0)
    .topSpaceToView(self,Scale_Y(10))
    .rightSpaceToView(self,0)
    .bottomSpaceToView(self,0);
}

/**
 *  设置显示日期
 *
 *  @param dateStr 日期字符串
 */
- (void)setDateView :(NSString *)dateStr;
{
    NSArray *dataArray = [dateStr componentsSeparatedByString:@"-"];
    if (dataArray.count==3) {
        mouthLabel.text = [[dateStr componentsSeparatedByString:@"-"] objectAtIndex:1];
        dayLabel.text = [[dateStr componentsSeparatedByString:@"-"] objectAtIndex:2];
    }
}

@end
