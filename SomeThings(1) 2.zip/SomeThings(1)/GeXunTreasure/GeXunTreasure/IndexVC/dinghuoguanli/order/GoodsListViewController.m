//
//  GoodsListViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsListViewController.h"
#import "GoodsTableViewCell.h"
#include "GoodsDetailsViewController.h"

@interface GoodsListViewController ()
<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UISearchBar *mySearchBar;
    UITableView *Tb;
}
@end

@implementation GoodsListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"商品列表" :NO];
    [super  creatRightNavCarButton];
    
    mySearchBar = [[UISearchBar alloc] init];
    [self.sc addSubview:mySearchBar];
    mySearchBar.sd_layout.leftSpaceToView(self.sc,Scale_X(5)).topSpaceToView(self.sc,70).rightSpaceToView(self.sc,Scale_X(5)).heightIs(30);
    mySearchBar.placeholder = @"搜索商品名称、编码";
    mySearchBar.delegate =self;
    mySearchBar.layer.cornerRadius=5;
    mySearchBar.layer.masksToBounds=YES;
    [mySearchBar setBackgroundImage:[UIImage imageNamed:@"searchBg"]];
    [mySearchBar setSearchFieldBackgroundImage:[UIImage imageNamed:@"searchBg"] forState:UIControlStateNormal];
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor whiteColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=NO;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(mySearchBar,Scale_Y(5)).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,0);
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65*NEWY;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 3;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    GoodsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[GoodsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    [cell cellClick:^(NSInteger cellIndex) {
        NSLog(@"KKK %ld",(long)cellIndex);
    }];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self.navigationController pushViewController:[[GoodsDetailsViewController alloc]init] animated:YES];
}
#pragma UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    //    searchResults = [[NSMutableArray alloc]init];
    //    if (mySearchBar.text.length>0&&![ChineseInclude isIncludeChineseInString:mySearchBar.text]) {
    //        for (int i=0; i<dataArray.count; i++) {
    //            if ([ChineseInclude isIncludeChineseInString:dataArray[i]]) {
    //                NSString *tempPinYinStr = [PinYinForObjc chineseConvertToPinYin:dataArray[i]];
    //                NSRange titleResult=[tempPinYinStr rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
    //                if (titleResult.length>0) {
    //                    [searchResults addObject:dataArray[i]];
    //                }
    //            }
    //            else {
    //                NSRange titleResult=[dataArray[i] rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
    //                if (titleResult.length>0) {
    //                    [searchResults addObject:dataArray[i]];
    //                }
    //            }
    //        }
    //    } else if (mySearchBar.text.length>0&&[ChineseInclude isIncludeChineseInString:mySearchBar.text]) {
    //        for (NSString *tempStr in dataArray) {
    //            NSRange titleResult=[tempStr rangeOfString:mySearchBar.text options:NSCaseInsensitiveSearch];
    //            if (titleResult.length>0) {
    //                [searchResults addObject:tempStr];
    //            }
    //        }
    //    }
    
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}


@end
