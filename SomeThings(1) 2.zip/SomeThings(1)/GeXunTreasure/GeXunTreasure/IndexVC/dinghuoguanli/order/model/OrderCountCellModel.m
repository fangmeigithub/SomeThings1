//
//  OrderCountCellMedol.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "OrderCountCellModel.h"

@implementation OrderCountCellModel


- (instancetype)initModelWithDic:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;

}

+ (instancetype)initModelWithDic :(NSDictionary *)dic;
{
    return [[super alloc] initModelWithDic:dic];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
}
@end
