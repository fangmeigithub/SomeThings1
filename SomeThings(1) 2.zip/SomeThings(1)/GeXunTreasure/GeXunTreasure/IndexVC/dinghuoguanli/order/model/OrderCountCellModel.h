//
//  OrderCountCellMedol.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OrderCountCellModel.h"

@interface OrderCountCellModel : NSObject

@property(strong,nonatomic)NSString *mounth;
@property(strong,nonatomic)NSString *number;
@property(strong,nonatomic)NSString *money;

+ (instancetype)initModelWithDic :(NSDictionary *)dic;
@end
