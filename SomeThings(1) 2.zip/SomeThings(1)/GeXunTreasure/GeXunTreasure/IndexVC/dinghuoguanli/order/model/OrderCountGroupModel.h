//
//  OrderGroupModel.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/16.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderCountGroupModel : NSObject


@property(strong,nonatomic)NSString *year;
@property(strong,nonatomic)NSArray *monthArray;

@property(assign,nonatomic) BOOL isOpen;

+ (instancetype)initModelWithDic :(NSDictionary *)dataDic;

+ (NSMutableArray *)getDataDic;
@end
