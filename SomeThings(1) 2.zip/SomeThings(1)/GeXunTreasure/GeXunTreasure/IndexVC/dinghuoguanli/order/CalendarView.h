//
//  CalendarView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/10.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalendarView : UIView
{
    UILabel *mouthLabel;
    UILabel *dayLabel;
}
//这是一个日历小试图，根据传进来的日期，来显示

/**
 *  设置显示日期
 *
 *  @param dateStr 日期字符串
 */
- (void)initSubV;
- (void)setDateView :(NSString *)dateStr;

@end
