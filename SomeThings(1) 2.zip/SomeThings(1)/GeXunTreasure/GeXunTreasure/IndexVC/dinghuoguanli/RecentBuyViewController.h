//
//  RecentBuyViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"
#import "RecentBuyTableViewCell.h"

@interface RecentBuyViewController : BaseViewController

<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *Tb;
}
@end
