//
//  RecentBuyTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol collectTableViewCellDelegate <NSObject>

@optional
- (void)addGoodsToCar :(NSInteger )cellTag;//加入购物车
- (void)selectGoodsForDelect :(NSInteger )cellTag;//选中删除
- (void)cancelSelectGoodsForDelect:(NSInteger )cellTag;//取消选中删除


@end

@interface RecentBuyTableViewCell : UITableViewCell
{
    UIButton *sendToGoodsCar;
    UIButton *delectButton;
}

@property(strong,nonatomic)UIImageView *goodsImageView;

@property(strong,nonatomic)UILabel *codeLabel;
@property(strong,nonatomic)UILabel *nameLabel;
@property(strong,nonatomic)UILabel *contentLabel;
@property (assign,nonatomic)BOOL isEdit;

@property(assign,nonatomic)id <collectTableViewCellDelegate> myDelegate;

@end
