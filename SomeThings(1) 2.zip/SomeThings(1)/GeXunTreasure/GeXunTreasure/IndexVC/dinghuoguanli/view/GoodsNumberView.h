//
//  GoodsNumberView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/9.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^cellNumberBackBlock)(NSInteger cellIndex);
@interface GoodsNumberView : UIView
{
    NSInteger number;
    UILabel *numberL;
}
@property(copy,nonatomic) cellNumberBackBlock cellNumberBlock;

- (void)cellNumberChangeClick :(cellNumberBackBlock)block;
- (instancetype)init;
@end
