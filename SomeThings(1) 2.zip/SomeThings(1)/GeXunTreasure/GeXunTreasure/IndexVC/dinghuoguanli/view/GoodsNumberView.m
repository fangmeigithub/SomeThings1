//
//  GoodsNumberView.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/9.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsNumberView.h"



@implementation GoodsNumberView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        // 上面的线
        UIView *headLine = [UIView new];
        headLine.backgroundColor = ViewlineColor;
        [self addSubview:headLine];
        headLine.sd_layout.leftSpaceToView(self,0).topSpaceToView(self,0).rightSpaceToView(self,0).heightIs(0.8);
        
        
        UILabel *numberLabel = [MethodTool creatLabelWithAttribute:@"订购数量    起定量：1" :13 :1 :ORANGE_COLOR];
        [self addSubview:numberLabel];
        numberLabel.attributedText = [self creatAttributedString:numberLabel.text];
        numberLabel.sd_layout.leftSpaceToView(self,10).centerYEqualToView(self).widthIs(200).heightIs(15);
        
        
        for (int i = 0; i<2; i++) {
            UIButton *addOrReduceButton = [MethodTool creatButtonWithAttribute:@"" :1 :[UIColor clearColor] :[UIColor clearColor]];
            [self addSubview:addOrReduceButton];
            addOrReduceButton.tag = 100+i;
            [addOrReduceButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
            addOrReduceButton.sd_layout.rightSpaceToView(self,((5+i*54)*NEWX)).centerYEqualToView(self).widthIs(30).heightIs(30);
        }
        
        UIImageView *addOrReduceImageView= [MethodTool creatImageWithAttribute:@"addOrReduce.png"];
        [self addSubview:addOrReduceImageView];
        addOrReduceImageView.sd_layout.rightSpaceToView(self,(10*NEWX)).centerYEqualToView(self).widthIs(75).heightIs(25);
        
        number = 1;
        numberL= [MethodTool creatLabelWithAttribute:@"1" :14 :2 :GrayTextColor];
        [self addSubview:numberL];
        numberL.sd_layout.centerXEqualToView(addOrReduceImageView).centerYEqualToView(addOrReduceImageView).widthIs(30).heightIs(15);
        
        // 下面的线
        UIView *bottowLine = [UIView new];
        bottowLine.backgroundColor = ViewlineColor;
        [self addSubview:bottowLine];
        bottowLine.sd_layout.leftSpaceToView(self,0).bottomSpaceToView(self,0).rightSpaceToView(self,0).heightIs(0.8);
        
    }
    return self;
};

//创造属性字符（截取部分颜色变化）
-(NSMutableAttributedString *)creatAttributedString :(NSString *)textTitle
{
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:textTitle];
    [str addAttribute:NSForegroundColorAttributeName value:NEWSTITLECOLOR range:NSMakeRange(0, textTitle.length-1)];
    return  str;
}

// 按钮点击
- (void)click :(UIButton *)sender{
    switch (sender.tag) {
            //增加
        case 100:
            number++;
            self.cellNumberBlock(number);
            break;
            //减少
        case 101:
            if (number>1) {
                number--;
                self.cellNumberBlock(number);
            }
            break;
            
        default:
            break;
    }
    numberL.text = [NSString stringWithFormat:@"%ld",(long)number];
}
- (void)cellNumberChangeClick :(cellNumberBackBlock)block;{
    self.cellNumberBlock = block;
}



@end
