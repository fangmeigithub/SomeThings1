//
//  GoodsClassifyViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface GoodsClassifyViewController : BaseViewController

@end
