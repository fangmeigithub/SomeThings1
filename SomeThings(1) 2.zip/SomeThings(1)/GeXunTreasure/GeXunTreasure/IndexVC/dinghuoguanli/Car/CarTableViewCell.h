//
//  CarTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol carCellDelegate <NSObject>

@optional
- (void)cellRowSelect :(NSInteger )cellIndex;       //点击购物车某一个cell 去看产品详情
- (void)cellDelectButtonSelect :(NSInteger )cellIndex; //点击购物车某一个cell 上的删除按钮
- (void)cellNunberChang :(NSInteger)cellIndex :(NSInteger )number;

@end

@interface CarTableViewCell : UITableViewCell

@property(strong,nonatomic)UIImageView *goodsImageView;

@property(strong,nonatomic)UILabel *codeLabel;
@property(strong,nonatomic)UILabel *nameLabel;
@property(strong,nonatomic)UILabel *contentLabel;

@property (nonatomic,assign) id <carCellDelegate> mydelegate;

@end
