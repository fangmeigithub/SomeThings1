//
//  CarTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CarTableViewCell.h"
#import "GoodsNumberView.h"

@implementation CarTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = RGB(245, 246, 246, 1);
        [self addSubview:bgView];
        
        
        bgView.sd_layout
        .leftSpaceToView(self,0)
        .topSpaceToView(self,0)
        .rightSpaceToView(self,0)
        .heightIs(Scale_Y(65));
        
        
        self.goodsImageView = [MethodTool creatImageWithAttribute:@"effect.png"];
        [bgView addSubview:self.goodsImageView];
        self.goodsImageView.sd_layout
        .leftSpaceToView(bgView,Scale_X(5))
        .topSpaceToView(bgView,Scale_Y(5))
        .bottomSpaceToView(bgView,Scale_Y(5))
        .widthEqualToHeight();
        
        
        
        self.codeLabel = [MethodTool creatLabelWithAttribute:@"编号：009876565" :13 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.codeLabel];
        self.codeLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .topSpaceToView(bgView,5)
        .widthIs(Scale_X(200))
        .heightIs(15);
        
        
        self.nameLabel = [MethodTool creatLabelWithAttribute:@"阿木正运动透气跑鞋" :13 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.nameLabel];
        self.nameLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .centerYEqualToView(bgView)
        .widthIs(Scale_X(200))
        .heightIs(15);
        
        
        self.contentLabel = [MethodTool creatLabelWithAttribute:@"¥ 1200.00" :13 :1 :ORANGE_COLOR];
        [bgView addSubview:self.contentLabel];
        self.contentLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .bottomSpaceToView(bgView,Scale_Y(5))
        .widthIs(Scale_X(100))
        .heightIs(15);
        
        
        //上面的线
        UIView *headLineV = [UIView new];
        headLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:headLineV];
        headLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,0).heightIs(0.8);
        
        
        //删除商品
        UIButton *delectGoodsCar = [MethodTool creatButtonWithAttribute:@"删除" :10 :ORANGE_COLOR :[UIColor whiteColor]];
        [bgView addSubview:delectGoodsCar];
        delectGoodsCar.layer.cornerRadius = 3;
        [delectGoodsCar addTarget:self action:@selector(delectGoods) forControlEvents:UIControlEventTouchUpInside];
        delectGoodsCar.sd_layout.rightSpaceToView(bgView,Scale_X(10)).centerYEqualToView(bgView).widthIs(Scale_X(44)).heightIs(Scale_Y(18));
        
        
        GoodsNumberView *goodsV = [[GoodsNumberView alloc]init];
        [self addSubview:goodsV];
        [goodsV cellNumberChangeClick:^(NSInteger cellIndex) {
            DMLog(@"数量:%ld",cellIndex);
        }];
        goodsV.sd_layout.leftSpaceToView(self ,0).topSpaceToView(bgView,0).rightSpaceToView(self,0).heightIs(Scale_Y(40) );
        
    }
    return self;
}
@end
