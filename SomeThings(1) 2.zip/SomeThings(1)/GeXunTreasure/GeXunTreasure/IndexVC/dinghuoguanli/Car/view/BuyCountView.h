
//
//  BuyCountView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/20.
//  Copyright © 2016年 liubaojian. All rights reserved.

#import <UIKit/UIKit.h>

@interface BuyCountView : UIView
@property(nonatomic, retain)UILabel *lb;
@property(nonatomic, retain)UIButton *bt_reduce;
@property(nonatomic, retain)UITextField *tf_count;
@property(nonatomic, retain)UIButton *bt_add;
@end
