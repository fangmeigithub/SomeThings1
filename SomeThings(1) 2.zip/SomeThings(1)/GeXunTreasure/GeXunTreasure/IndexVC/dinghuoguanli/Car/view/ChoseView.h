//
//  ChoseView.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/20.
//  Copyright © 2016年 liubaojian. All rights reserved.


#import <UIKit/UIKit.h>
#import "TypeView.h"
#import "BuyCountView.h"



@interface ChoseView : UIView<UITextFieldDelegate,UIAlertViewDelegate,TypeSeleteDelegete>
{
    NSArray *sizearr;//型号数组
    NSArray *colorarr;//分类数组
    NSDictionary *stockarr;//商品库存量
    
    UIView *supView;
    UIScrollView *bgview;
    
    CGPoint center;
}
@property(nonatomic, retain)UIView *alphaiView;
@property(nonatomic, retain)UIView *whiteView;

@property(nonatomic, retain)UIImageView *img;

@property(nonatomic, retain)UILabel *lb_price;
@property(nonatomic, retain)UILabel *lb_stock;
@property(nonatomic, retain)UILabel *lb_detail;
@property(nonatomic, retain)UILabel *lb_line;

@property(nonatomic, retain)UIScrollView *mainscrollview;

@property(nonatomic, retain)TypeView *sizeView;
@property(nonatomic, retain)TypeView *colorView;
@property(nonatomic, retain)BuyCountView *countView;

@property(nonatomic, retain)UIButton *bt_sure;
@property(nonatomic, retain)UIButton *bt_cancle;

@property(nonatomic) int stock;

+ (instancetype)showInSupView :(UIView *)superView :(UIScrollView *)bgView;
- (void)showOut;
@end
