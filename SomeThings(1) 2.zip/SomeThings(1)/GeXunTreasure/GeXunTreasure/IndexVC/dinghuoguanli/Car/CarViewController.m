//
//  CarViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/11.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CarViewController.h"
#import "CarTableViewCell.h"

@interface CarViewController ()
<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *Tb;
    UILabel *numberlabel,*allPriceLabel;
}
@end

@implementation CarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"购物车" :NO];
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor whiteColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,Scale_Y(43));
    
    
    //底部的合计价格和提交订单
    UIView *lineView = [UIView new];
    lineView.backgroundColor = ViewlineColor;
    [self.view addSubview:lineView];
    lineView.sd_layout.leftSpaceToView(self.view,0).bottomSpaceToView(self.view,(41*NEWY)).widthRatioToView(self.view,0.6).heightIs(Scale_Y(0.5));
    
    UIImageView *collectbutton = [MethodTool creatImageWithAttribute:@"jianbian"];
    [self.view addSubview:collectbutton];
    collectbutton.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(lineView,0).bottomSpaceToView(self.view,0).widthRatioToView(self.view,0.6);
    
    //数量
    numberlabel = [MethodTool creatLabelWithAttribute:@"商品：22" :13 :1 :GrayTextColor];
    [collectbutton addSubview:numberlabel];
    numberlabel.sd_layout.leftSpaceToView(collectbutton,Scale_X(10)).centerYEqualToView(collectbutton).widthIs(Scale_X(60)).heightIs(15);
    
    //总价
    allPriceLabel = [MethodTool creatLabelWithAttribute:@"合计：¥2400:00" :13 :1 :ORANGE_COLOR];
    [collectbutton addSubview:allPriceLabel];
    allPriceLabel.sd_layout.leftSpaceToView(numberlabel,0).centerYEqualToView(collectbutton).widthIs(Scale_X(100)).heightIs(15);
    
    
    UIButton *addGoodsCar = [MethodTool creatButtonWithAttribute:@"提交订单" :12 :ORANGE_COLOR :[UIColor whiteColor]];
    [self.view addSubview:addGoodsCar];
    [addGoodsCar addTarget:self action:@selector(admitOrder) forControlEvents:UIControlEventTouchUpInside];
    addGoodsCar.sd_layout.leftSpaceToView(collectbutton,0).topEqualToView(collectbutton).bottomSpaceToView(self.view,0).widthRatioToView(self.view,0.4);
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 109*NEWY;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    CarTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[CarTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

/**
 *  提交订单
 */
- (void)admitOrder
{
    
}




@end
