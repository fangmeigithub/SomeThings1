//
//  GoodsDetailsViewController.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/6.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "BaseViewController.h"

@interface GoodsDetailsViewController : BaseViewController

@end
