//
//  GoodsTableViewCell.h
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^cellIndexBackBlock)(NSInteger cellIndex);

@interface GoodsTableViewCell : UITableViewCell


@property(strong,nonatomic)UIImageView *goodsImageView;
@property(strong,nonatomic)UILabel *nameLabel;
@property(strong,nonatomic)UILabel *contentLabel;


@property(copy,nonatomic) cellIndexBackBlock cellIndexBlock;

- (void)cellClick :(cellIndexBackBlock)block;
@end
