//
//  RecentBuyViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "RecentBuyViewController.h"


@interface RecentBuyViewController ()

@end

@implementation RecentBuyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super creatNavView:@"最近订购" :NO];
    [super  creatRightNavCarButton];
    
    Tb = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    Tb.backgroundColor=[UIColor whiteColor];
    Tb.delegate=self;
    Tb.dataSource=self;
    Tb.scrollEnabled=YES;
    Tb.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.sc addSubview:Tb];
    Tb.sd_layout.leftSpaceToView(self.sc,0).topSpaceToView(self.sc,64).rightSpaceToView(self.sc,0).bottomSpaceToView(self.sc,Scale_Y(5));
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65*NEWY;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    RecentBuyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[RecentBuyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    

}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.contentView.frame = CGRectMake(-WIDTH, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    [UIView animateWithDuration:0.7 animations:^{
        cell.contentView.frame = CGRectMake(0, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height);
    } completion:^(BOOL finished) {
        ;
    }];
}

@end
