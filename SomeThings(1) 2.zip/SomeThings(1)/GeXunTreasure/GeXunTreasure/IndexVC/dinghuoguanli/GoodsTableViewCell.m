//
//  GoodsTableViewCell.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/5.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "GoodsTableViewCell.h"

@implementation GoodsTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIView *bgView = [UIView new];
        bgView.backgroundColor = RGB(245, 246, 246, 1);
        [self.contentView addSubview:bgView];
        

        bgView.sd_layout
        .leftSpaceToView(self.contentView,0)
        .topSpaceToView(self.contentView,0)
        .rightSpaceToView(self.contentView,0)
        .bottomSpaceToView(self.contentView,Scale_Y(5));
        
        
        self.goodsImageView = [MethodTool creatImageWithAttribute:@"effect.png"];
        [bgView addSubview:self.goodsImageView];
        self.goodsImageView.sd_layout
        .leftSpaceToView(bgView,Scale_X(5))
        .topSpaceToView(bgView,Scale_Y(5))
        .bottomSpaceToView(bgView,Scale_Y(5))
        .widthEqualToHeight();
        
        self.nameLabel = [MethodTool creatLabelWithAttribute:@"阿木正运动透气跑鞋" :13 :1 :NEWSTITLECOLOR];
        [bgView addSubview:self.nameLabel];
        self.nameLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .topSpaceToView(bgView,Scale_Y(10))
        .widthIs(200)
        .heightIs(15);
        
        
        self.contentLabel = [MethodTool creatLabelWithAttribute:@"¥ 1200.00" :14 :1 :ORANGE_COLOR];
        [bgView addSubview:self.contentLabel];
        self.contentLabel.sd_layout
        .leftSpaceToView(self.goodsImageView,Scale_X(10))
        .bottomSpaceToView(bgView,Scale_Y(10))
        .widthIs(100)
        .heightIs(15);
    
        
        //上面的线
        UIView *headLineV = [UIView new];
        headLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:headLineV];
        headLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).topSpaceToView(bgView,0).heightIs(0.8);
        
        //下面的线
        UIView *bottowLineV = [UIView new];
        bottowLineV.backgroundColor = ViewlineColor;
        [bgView addSubview:bottowLineV];
        bottowLineV.sd_layout.leftSpaceToView(bgView,0).rightSpaceToView(bgView,0).bottomSpaceToView(bgView,0).heightIs(0.8);
        
    
        //加入购物车
        UIButton *sendToGoodsCar = [MethodTool creatButtonWithAttribute:@"加入购物车" :12 :ORANGE_COLOR :[UIColor whiteColor]];
        [bgView addSubview:sendToGoodsCar];
        sendToGoodsCar.layer.cornerRadius = 3;
        [sendToGoodsCar addTarget:self action:@selector(sendToCar) forControlEvents:UIControlEventTouchUpInside];
        sendToGoodsCar.sd_layout.rightSpaceToView(bgView,10).centerYEqualToView(bgView).widthIs(Scale_X(66)).heightIs(Scale_Y(20));

        
    }
    return self;
}

-(void)sendToCar
{
    self.cellIndexBlock(self.tag);
}
- (void)cellClick :(cellIndexBackBlock)block;{
    self.cellIndexBlock = block;
}
@end
