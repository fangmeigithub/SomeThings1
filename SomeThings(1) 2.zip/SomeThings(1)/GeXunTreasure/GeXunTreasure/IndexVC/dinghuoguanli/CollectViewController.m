//
//  CollectViewController.m
//  GeXunTreasure
//
//  Created by liubaojian on 16/5/6.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CollectViewController.h"

@interface CollectViewController ()
<collectTableViewCellDelegate>

@end

@implementation CollectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [super creatNavView:@"收藏夹" :NO];
    
    editButton = [MethodTool creatButtonWithAttribute:@"管理收藏夹" :14 :ORANGE_COLOR :[UIColor whiteColor]];
    [self.sc addSubview:editButton];
    editButton.sd_layout.leftSpaceToView(self.sc,0).bottomSpaceToView(self.sc,0).rightSpaceToView(self.sc,0).heightIs(Scale_Y(40));
    [editButton addTarget:self action:@selector(editGoodsList) forControlEvents:UIControlEventTouchUpInside];
    
    //编辑状态下的底部试图
    bottowView = [UIView new];
    [self.sc addSubview:bottowView];
    bottowView.backgroundColor = RGB(245, 246, 246, 1);
    bottowView.sd_layout.leftSpaceToView(self.sc,0).bottomSpaceToView(self.sc,0).rightSpaceToView(self.sc,0).heightIs(Scale_Y(40));
    bottowView.hidden = YES;
    
    
    //上面的线
    UIView *headLineV = [UIView new];
    headLineV.backgroundColor = ViewlineColor;
    [bottowView addSubview:headLineV];
    headLineV.sd_layout.leftSpaceToView(bottowView,0).rightSpaceToView(bottowView,0).topSpaceToView(bottowView,0).heightIs(0.8);

    
    UIButton *allSelectButton = [MethodTool creatButtonWithAttribute:@"" :10 :[UIColor clearColor] :[UIColor clearColor]];
    [bottowView addSubview:allSelectButton];
    [allSelectButton setBackgroundImage:[UIImage imageNamed:@"delectBg"] forState:UIControlStateNormal];
    [allSelectButton addTarget:self action:@selector(allSelect) forControlEvents:UIControlEventTouchUpInside];
    allSelectButton.sd_layout.leftSpaceToView(bottowView,0).centerYEqualToView(bottowView).widthIs(Scale_X(30)).heightIs(Scale_X(30));
    
    UILabel *leftText = [MethodTool creatLabelWithAttribute:@"全选" :12 :1 :GrayTextColor];
    [bottowView addSubview:leftText];
    leftText.sd_layout.leftSpaceToView(bottowView,Scale_X(30)).centerYEqualToView(bottowView).widthIs(Scale_X(50)).heightIs(Scale_Y(20));
    //[self.view layoutSubviews];
    
    
    //删除
    UIButton *delectSelectButton = [MethodTool creatButtonWithAttribute:@"删除" :10 :ORANGE_COLOR :[UIColor whiteColor]];
    [bottowView addSubview:delectSelectButton];
    [delectSelectButton addTarget:self action:@selector(delectSelect) forControlEvents:UIControlEventTouchUpInside];
    delectSelectButton.sd_layout.rightSpaceToView(bottowView,Scale_X(10)).centerYEqualToView(bottowView).widthIs(Scale_X(60)).heightIs(Scale_Y(25));

    //取消
    UIButton *cancelButton = [MethodTool creatButtonWithAttribute:@"取消" :10 :RGB(245, 246, 246, 1) :GrayTextColor];
    [bottowView addSubview:cancelButton];
    [cancelButton.layer setBorderWidth:Scale_X(0.6)];
    [cancelButton.layer setBorderColor:ViewlineColor.CGColor];
    [cancelButton addTarget:self action:@selector(cancelButton) forControlEvents:UIControlEventTouchUpInside];
    cancelButton.sd_layout.rightSpaceToView(delectSelectButton,Scale_X(10)).centerYEqualToView(bottowView).widthIs(Scale_X(60)).heightIs(Scale_Y(25));
    
    
}
//https://apiview.com/

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"firstCell";
    RecentBuyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[RecentBuyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.tag = indexPath.row;
    cell.myDelegate = self;
    cell.isEdit = cellIsEdit;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
}

//编辑
- (void)editGoodsList
{
    cellIsEdit = YES;
    [Tb reloadData];
    bottowView.hidden = NO;
    editButton.hidden = YES;
}
//全选
- (void)allSelect
{
    
}
//删除选中的商品
- (void)delectSelect
{
    
}
//取消编辑
- (void)cancelButton
{
    cellIsEdit = NO;
    [Tb reloadData];
    bottowView.hidden = YES;
    editButton.hidden = NO;
}


#pragma mark－－－－－－－－－－－－－－－－－－－collectTableViewCellDelegate delegate－－－－－－－－－－－－－－－－

- (void)addGoodsToCar:(NSInteger)cellTag
{
    
}

- (void)selectGoodsForDelect:(NSInteger)cellTag
{
    
}

- (void)cancelSelectGoodsForDelect:(NSInteger)cellTag
{
    
}


@end
